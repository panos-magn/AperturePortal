# Aperture — Production Readiness Guide

This document covers everything needed to deploy the Aperture Client Media
Portal for real client use.

---

## ✅ What's Already Done

The portal is feature-complete and production-ready in this sandbox:

- **Secure image + video proxy** — all media streams through `/api/gallery/images/[fileId]`; Google Drive URLs are never exposed to the browser.
- **HTTP 206 range requests** — video seeking + large-image partial loads work.
- **TTL caching** — 10-minute list cache + 30-minute byte cache shield the Drive API from rate limits.
- **Access gate** — PIN-protected login screen (cookie-based, httpOnly, 30-day session).
- **Error boundary** — graceful crash recovery instead of blank screens.
- **Full feature set** — search, sort, favourites, multi-select + zip download, lightbox with zoom/pan/fullscreen/slideshow, masonry/grid layouts, recently-viewed, keyboard shortcuts, admin cache panel, configurable TTL.
- **LIVE mode** — connected to your Google Drive folder with a Service Account.

---

## 🔑 Access Protection

The portal is protected by a PIN gate. The current PIN is set in `.env`:

```
ACCESS_PIN=aperture2026
```

**Before sharing with clients:**
1. Change the PIN to something only you and your clients know.
2. The PIN is validated server-side; clients never see the value.
3. The session cookie lasts 30 days (clients won't need to re-enter frequently).
4. To disable auth entirely (open access), set `ACCESS_PIN=` (empty).

---

## 🚀 Sharing with Clients (This Sandbox)

1. Use the **Preview Panel** on the right side of the interface.
2. Click **"Open in New Tab"** — this gives you a shareable URL.
3. Send that URL + the access PIN to your client.
4. They'll see the login screen → enter the PIN → see the gallery.

> ⚠️ **Sandbox caveat:** This dev server restarts periodically. For a
> permanent production deployment, follow the real deployment guide below.

---

## 📦 Real Production Deployment

For a permanent, always-on deployment outside this sandbox:

### Option A — Vercel (recommended, easiest)

1. Push the project to a GitHub repository.
2. Go to [vercel.com](https://vercel.com) → Import the repo.
3. Add environment variables in the Vercel dashboard:
   - `GOOGLE_DRIVE_FOLDER_ID` — your Drive folder ID
   - `GOOGLE_CREDENTIALS_PATH` — `./credentials.json`
   - `ACCESS_PIN` — your client access code
4. Upload `credentials.json` — add its contents as a Vercel secret or use
   their file system (note: Vercel doesn't persist files, so you'll need to
   base64-encode the credentials and decode at runtime, OR store the JSON
   in a single env var like `GOOGLE_CREDENTIALS_JSON`).
5. Deploy. Vercel gives you a `https://your-app.vercel.app` URL.

### Option B — Self-hosted (VPS / Docker)

1. Build: `bun run build` (produces `.next/standalone`).
2. Run: `NODE_ENV=production bun .next/standalone/server.js`
3. Put behind a reverse proxy (Caddy/Nginx) with HTTPS.
4. Keep `credentials.json` on the server (not in git).
5. Set all env vars in the server environment.

### Option C — Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package.json bun.lock ./
RUN npm install -g bun && bun install --frozen-lockfile
COPY . .
COPY credentials.json .
RUN bun run build
ENV NODE_ENV=production
EXPOSE 3000
CMD ["bun", ".next/standalone/server.js"]
```

---

## 🔒 Security Checklist

- [x] `credentials.json` is in `.gitignore` (never committed to git)
- [x] Access PIN protects the portal from public access
- [x] Session cookie is `httpOnly` (XSS protection)
- [x] Drive URLs are never exposed — all media flows through the proxy
- [x] Service Account has `drive.readonly` scope only (least privilege)
- [x] Error boundary prevents information leakage on crashes
- [ ] **Before production:** change the default PIN (`aperture2026`)
- [ ] **Before production:** set `secure: true` on cookies (automatic when `NODE_ENV=production`)
- [ ] **Before production:** enable HTTPS (Vercel does this automatically; self-hosted needs Caddy/Nginx + Let's Encrypt)

---

## 📋 Client Handoff Checklist

When handing the link to a client:

1. ✅ Set a memorable PIN in `.env` → `ACCESS_PIN=your-pin-here`
2. ✅ Upload images/videos to the [Drive folder](https://drive.google.com/drive/u/3/folders/1QTbg8NGoZhO3a0tawRJ7ZQIJlZ-BjH9o)
3. ✅ Restart the server (or hit Refresh) so new media appears
4. ✅ Share the preview URL + PIN with the client
5. ✅ Tell the client:
   - Click any image to open the full-screen viewer
   - Use `?` to see all keyboard shortcuts
   - They can search, sort, favourite, and download images
   - Videos play inline with controls

---

## 🛠️ Ongoing Maintenance

- **Add new media:** just upload to the Drive folder → hit Refresh in the portal (or wait 10 min for the cache to auto-expire).
- **Change the PIN:** edit `ACCESS_PIN` in `.env` → restart. Existing client sessions expire on next page load (cookie validation is server-side per request... actually the cookie is the PIN itself, so old cookies stop working when the PIN changes).
- **Revoke access:** change the PIN. All existing sessions become invalid instantly.
- **Monitor Drive API quota:** the TTL cache minimises API calls. If you hit rate limits, increase `GALLERY_CACHE_TTL_MS`.
