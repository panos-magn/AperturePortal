import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";
import path from "path";

const OUT_DIR = path.join(process.cwd(), "public", "gallery");

const ITEMS: { name: string; prompt: string }[] = [
  {
    name: "mountain-lake.jpg",
    prompt:
      "Professional landscape photograph of a serene alpine lake at golden hour, mirror-like reflection of snow-capped mountains, dramatic clouds, warm light, ultra detailed, high resolution, no text",
  },
  {
    name: "ocean-sunset.jpg",
    prompt:
      "Professional landscape photograph of a calm ocean at sunset, vibrant orange and pink sky, gentle waves, silhouette of rocks, long exposure, ultra detailed, high resolution, no text",
  },
  {
    name: "forest-path.jpg",
    prompt:
      "Professional landscape photograph of a misty forest path in autumn, sunbeams through tall trees, fallen leaves, atmospheric depth, ultra detailed, high resolution, no text",
  },
  {
    name: "desert-dunes.jpg",
    prompt:
      "Professional landscape photograph of rolling desert sand dunes at blue hour, smooth curves, subtle shadows, minimal composition, ultra detailed, high resolution, no text",
  },
  {
    name: "city-skyline.jpg",
    prompt:
      "Professional landscape photograph of a modern city skyline at night, glowing skyscrapers, river reflection, deep blue sky, long exposure light trails, ultra detailed, high resolution, no text",
  },
  {
    name: "aurora-fjord.jpg",
    prompt:
      "Professional landscape photograph of a Norwegian fjord under a vivid green aurora borealis, starry sky, snow on mountains, mirror reflection, ultra detailed, high resolution, no text",
  },
  {
    name: "lavender-field.jpg",
    prompt:
      "Professional landscape photograph of a purple lavender field at sunrise, a lone tree on the horizon, soft mist, rows of flowers, warm light, ultra detailed, high resolution, no text",
  },
  {
    name: "waterfall-canyon.jpg",
    prompt:
      "Professional landscape photograph of a powerful waterfall in a lush green canyon, mist, long exposure silky water, mossy rocks, ultra detailed, high resolution, no text",
  },
];

async function main() {
  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });
  const zai = await ZAI.create();

  const manifest: { id: string; name: string; file: string; mime: string }[] = [];

  for (let i = 0; i < ITEMS.length; i++) {
    const item = ITEMS[i];
    const outPath = path.join(OUT_DIR, item.name);
    if (fs.existsSync(outPath)) {
      console.log(`skip (exists): ${item.name}`);
      manifest.push({
        id: `demo-${i + 1}`,
        name: item.name.replace(/\.jpg$/, "").replace(/-/g, " "),
        file: `/gallery/${item.name}`,
        mime: "image/jpeg",
      });
      continue;
    }
    try {
      const res = await zai.images.generations.create({
        prompt: item.prompt,
        size: "1344x768",
      });
      const b64 = res.data[0].base64;
      fs.writeFileSync(outPath, Buffer.from(b64, "base64"));
      console.log(`generated: ${item.name}`);
      manifest.push({
        id: `demo-${i + 1}`,
        name: item.name.replace(/\.jpg$/, "").replace(/-/g, " "),
        file: `/gallery/${item.name}`,
        mime: "image/jpeg",
      });
    } catch (e) {
      console.error(`failed: ${item.name}`, e);
    }
  }

  fs.writeFileSync(
    path.join(OUT_DIR, "manifest.json"),
    JSON.stringify(manifest, null, 2)
  );
  console.log(`manifest written with ${manifest.length} items`);
}

main();
