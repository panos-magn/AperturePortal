#!/usr/bin/env bash
# Watchdog: keeps the Next.js dev server alive on port 3000.
# Restarts it if it dies. Designed to be launched via setsid so it survives
# the bash tool session that starts it.
cd /home/z/my-project || exit 1

LOG=/home/z/my-project/dev.log
WDLOG=/tmp/dev-watchdog.log

echo "[watchdog] started $(date -Is)" >> "$WDLOG"

while true; do
  # Is anything listening on 3000?
  if ! curl -sf -o /dev/null --max-time 3 http://localhost:3000/ >/dev/null 2>&1; then
    echo "[watchdog] port 3000 down, starting dev server $(date -Is)" >> "$WDLOG"
    pkill -9 -f "next-server" 2>/dev/null
    pkill -9 -f "next dev" 2>/dev/null
    sleep 1
    # Start dev server in its own session, fully detached.
    setsid bash -c 'exec bun run dev' </dev/null >>"$LOG" 2>&1 &
    disown
    # Give it time to compile before checking again.
    sleep 25
  else
    sleep 8
  fi
done
