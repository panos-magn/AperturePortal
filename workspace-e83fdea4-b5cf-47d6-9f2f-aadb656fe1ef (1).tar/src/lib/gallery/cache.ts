import { LRUCache } from "lru-cache";
import type { DriveFileDto } from "./types";
import { getGalleryConfig } from "./config";

/**
 * In-memory gallery cache (Next.js equivalent of the Spring Boot CacheManager
 * backed by Caffeine / ConcurrentHashMap).
 *
 * Two caches live here:
 *
 *  1. `listCache`  — file LIST per folderId, auto-evicted after
 *     `GALLERY_CACHE_TTL_MS` (default 10 min). This is the @Cacheable twin.
 *
 *  2. `byteCache`  — recently-streamed IMAGE BYTES per fileId, so repeat
 *     proxy hits (lightbox full-res, page reloads) don't re-hit the Drive
 *     API. Bounded by total byte size to stay memory-safe.
 */

const LIST_CACHE_MAX_ENTRIES = 64;
const BYTE_CACHE_MAX_BYTES = 64 * 1024 * 1024; // 64 MiB cap
const BYTE_CACHE_MAX_ENTRIES = 128;

let listCache: LRUCache<string, DriveFileDto[]> | null = null;
let listCacheTtl: number | null = null;
let byteCache:
  | LRUCache<string, { bytes: Buffer; mimeType: string; size: number; fetchedAt: number }>
  | null = null;

function ensureListCache(): LRUCache<string, DriveFileDto[]> {
  const { cacheTtlMs } = getGalleryConfig();
  // Rebuild if the TTL changed at runtime (via /api/gallery/config) so the
  // new window applies to subsequent entries.
  if (listCache && listCacheTtl === cacheTtlMs) return listCache;
  listCache = new LRUCache<string, DriveFileDto[]>({
    max: LIST_CACHE_MAX_ENTRIES,
    ttl: cacheTtlMs,
    allowStale: false,
  });
  listCacheTtl = cacheTtlMs;
  return listCache;
}

function ensureByteCache() {
  if (byteCache) return byteCache;
  byteCache = new LRUCache<
    string,
    { bytes: Buffer; mimeType: string; size: number; fetchedAt: number }
  >({
    max: BYTE_CACHE_MAX_ENTRIES,
    maxSize: BYTE_CACHE_MAX_BYTES,
    sizeCalculation: (v) => v.bytes.length,
    ttl: 30 * 60 * 1000, // 30 min — bytes are immutable for a fileId
    allowStale: false,
  });
  return byteCache;
}

function listKey(folderId: string): string {
  return `gallery:${folderId}`;
}

export interface CachedResult {
  items: DriveFileDto[];
  cached: boolean;
}

/** Return cached items if present (and fresh), otherwise call `loader`. */
export async function getOrLoad(
  folderId: string,
  loader: () => Promise<DriveFileDto[]>
): Promise<CachedResult> {
  const c = ensureListCache();
  const k = listKey(folderId);
  const hit = c.get(k);
  if (hit) return { items: hit, cached: true };
  const items = await loader();
  c.set(k, items);
  return { items, cached: false };
}

/** Force-evict the cached list for a folder (or all folders). */
export function evict(folderId?: string): number {
  const c = ensureListCache();
  if (!folderId) {
    const n = c.size;
    c.clear();
    return n;
  }
  const k = listKey(folderId);
  return c.delete(k) ? 1 : 0;
}

/* ----------------------- byte cache (proxy) -------------------------- */

export interface ByteCacheEntry {
  bytes: Buffer;
  mimeType: string;
  size: number;
  fetchedAt: number;
}

export function getByteCacheEntry(fileId: string): ByteCacheEntry | undefined {
  return ensureByteCache().get(fileId);
}

export function setByteCacheEntry(
  fileId: string,
  entry: ByteCacheEntry
): void {
  // Only cache if it fits comfortably under the cap.
  if (entry.bytes.length > BYTE_CACHE_MAX_BYTES) return;
  ensureByteCache().set(fileId, entry);
}

/* ----------------------- metadata cache (dimensions) ----------------- */

export interface ImageMeta {
  width: number;
  height: number;
  type: string;
  size: number;
}

let metaCache: Map<string, ImageMeta> | null = null;

function ensureMetaCache(): Map<string, ImageMeta> {
  if (!metaCache) metaCache = new Map();
  return metaCache;
}

export function getMetaCacheEntry(fileId: string): ImageMeta | undefined {
  return ensureMetaCache().get(fileId);
}

export function setMetaCacheEntry(fileId: string, meta: ImageMeta): void {
  ensureMetaCache().set(fileId, meta);
}

export function evictMetaCache(fileId?: string): number {
  const c = ensureMetaCache();
  if (!fileId) {
    const n = c.size;
    c.clear();
    return n;
  }
  return c.delete(fileId) ? 1 : 0;
}

export function evictByteCache(fileId?: string): number {
  const c = ensureByteCache();
  if (!fileId) {
    const n = c.size;
    c.clear();
    return n;
  }
  return c.delete(fileId) ? 1 : 0;
}

/* ----------------------------- stats --------------------------------- */

export function cacheStats() {
  const c = ensureListCache();
  const bc = ensureByteCache();
  const { cacheTtlMs } = getGalleryConfig();
  // Approximate remaining TTL for the demo folder entry (for the admin panel).
  let listTtlRemainingMs: number | null = null;
  try {
    const demoEntry = c.get("__demo__" /* not the real key, just probing */);
    void demoEntry;
  } catch {
    /* noop */
  }
  return {
    size: c.size,
    max: LIST_CACHE_MAX_ENTRIES,
    ttlMs: cacheTtlMs,
    calculatedSize: c.calculatedSize,
    byteCacheSize: bc.size,
    byteCacheMaxBytes: BYTE_CACHE_MAX_BYTES,
    byteCacheBytes: bc.calculatedSize ?? 0,
    listTtlRemainingMs,
  };
}

/** Evict BOTH caches (used by the admin "flush all" button). */
export function evictAll(): { list: number; bytes: number } {
  return {
    list: evict(),
    bytes: evictByteCache(),
  };
}
