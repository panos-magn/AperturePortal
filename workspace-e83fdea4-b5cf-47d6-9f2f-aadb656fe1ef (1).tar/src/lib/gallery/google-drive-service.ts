import fs from "node:fs";
import path from "node:path";
import { google, type drive_v3 } from "googleapis";
import sharp from "sharp";
import type { DriveFileDto, GallerySource, GalleryHealthResponse } from "./types";
import { getGalleryConfig } from "./config";
import { DEMO_FILES, isDemoId, demoFileForId } from "./demo-data";
import {
  getOrLoad,
  evict,
  evictAll,
  cacheStats,
  getByteCacheEntry,
  setByteCacheEntry,
  getMetaCacheEntry,
  setMetaCacheEntry,
  type ImageMeta,
} from "./cache";

/**
 * GoogleDriveService
 *
 * Next.js equivalent of the Spring `GoogleDriveService` bean. It initialises
 * the official Google Drive client (`googleapis` = the Node twin of the Java
 * `google-api-services-drive` library) using a Service Account JSON key, and
 * exposes:
 *
 *   - listGallery(folderId)  -> @Cacheable list of images (auto-evicted)
 *   - streamFile(fileId)     -> raw byte stream for the secure proxy
 *   - healthCheck()          -> diagnostics for the admin panel
 *
 * When no `credentials.json` is present the service transparently falls back
 * to DEMO mode so the portal is fully functional for local preview / QA.
 */

let driveClient: drive_v3.Drive | null = null;
let initError: string | null = null;

interface ServiceAccountCreds {
  client_email: string;
  private_key: string;
  project_id?: string;
}

function loadCredentials(): ServiceAccountCreds | null {
  const { credentialsPath, credentialsExist } = getGalleryConfig();
  if (!credentialsExist) return null;
  try {
    const raw = fs.readFileSync(credentialsPath, "utf-8");
    const parsed = JSON.parse(raw);
    if (!parsed.client_email || !parsed.private_key) {
      initError =
        "credentials.json is missing client_email / private_key — not a valid Service Account key.";
      return null;
    }
    return parsed as ServiceAccountCreds;
  } catch (e) {
    initError = `Failed to read credentials: ${(e as Error).message}`;
    return null;
  }
}

/** Lazily build an authenticated Drive client. Returns null in demo mode. */
function getDriveClient(): drive_v3.Drive | null {
  if (initError) return null;
  if (driveClient) return driveClient;

  const creds = loadCredentials();
  if (!creds) return null;

  try {
    const auth = new google.auth.JWT({
      email: creds.client_email,
      key: creds.private_key,
      scopes: ["https://www.googleapis.com/auth/drive.readonly"],
    });
    driveClient = google.drive({ version: "v3", auth });
    return driveClient;
  } catch (e) {
    initError = `Failed to initialise Drive client: ${(e as Error).message}`;
    return null;
  }
}

/**
 * Raw Drive query — NOT cached. Queries the given folder for image files
 * (mimeType contains 'image/'), extracting File ID, Name, CreatedTime and
 * ThumbnailLink, ordered newest-first.
 */
async function fetchGalleryImages(
  folderId: string
): Promise<DriveFileDto[]> {
  const drive = getDriveClient();
  if (!drive) {
    throw new Error(initError ?? "Drive client unavailable");
  }

  const escaped = folderId.replace(/'/g, "\\'");
  // Query for both images AND videos (mimeType contains 'image/' OR 'video/').
  // Drive's query language doesn't support OR across different contains() on
  // the same field cleanly, so we use parentheses to group.
  const q = `'${escaped}' in parents and trashed = false and (mimeType contains 'image/' or mimeType contains 'video/')`;

  const res = await drive.files.list({
    q,
    fields: "files(id, name, createdTime, thumbnailLink, mimeType, size)",
    orderBy: "createdTime desc",
    pageSize: 200,
    supportsAllDrives: true,
    includeItemsFromAllDrives: true,
  });

  const files = res.data.files ?? [];
  return files.map((f) => {
    const mimeType = f.mimeType ?? "image/jpeg";
    return {
      id: f.id ?? "",
      name: f.name ?? "Untitled",
      createdTime: f.createdTime ?? new Date().toISOString(),
      thumbnailLink: f.thumbnailLink ?? undefined,
      mimeType,
      size: f.size ?? undefined,
      kind: (mimeType.startsWith("video/") ? "video" : "image") as "image" | "video",
    };
  });
}

export interface ListResult {
  items: DriveFileDto[];
  source: GallerySource;
  cached: boolean;
  folderId: string | null;
}

export interface ClientFolder {
  id: string;
  name: string;
  createdTime: string;
}

/**
 * Lists all subfolders of the configured root Drive folder — each subfolder
 * represents one client. Used by the admin dashboard.
 */
export async function listClientFolders(): Promise<ClientFolder[]> {
  const cfg = getGalleryConfig();
  if (cfg.demoMode) {
    // In demo mode, return a couple of fake clients so the dashboard renders.
    return [
      { id: "demo-client-1", name: "Acme Studios", createdTime: new Date().toISOString() },
      { id: "demo-client-2", name: "Northwind Co", createdTime: new Date().toISOString() },
    ];
  }
  const drive = getDriveClient();
  if (!drive) {
    throw new Error(initError ?? "Drive client unavailable");
  }
  const rootFolderId = cfg.folderId;
  const escaped = rootFolderId.replace(/'/g, "\\'");
  const res = await drive.files.list({
    q: `'${escaped}' in parents and trashed = false and mimeType = 'application/vnd.google-apps.folder'`,
    fields: "files(id, name, createdTime)",
    orderBy: "name",
    pageSize: 200,
    supportsAllDrives: true,
    includeItemsFromAllDrives: true,
  });
  return (res.data.files ?? []).map((f) => ({
    id: f.id ?? "",
    name: f.name ?? "Unnamed",
    createdTime: f.createdTime ?? new Date().toISOString(),
  }));
}

/**
 * Cached list accessor — the @Cacheable twin.
 * Key: #folderId. TTL: GALLERY_CACHE_TTL_MS (default 10m).
 *
 * When `overrideFolderId` is supplied (admin/client view), it takes
 * precedence over the env-configured root folder — this is how per-client
 * galleries work (each client's subfolder is queried directly).
 */
export async function listGallery(
  overrideFolderId?: string
): Promise<ListResult> {
  const cfg = getGalleryConfig();

  if (cfg.demoMode && !overrideFolderId) {
    // Demo mode also honours the cache so the eviction endpoint is testable.
    const { items, cached } = await getOrLoad("__demo__", async () => DEMO_FILES);
    return {
      items,
      source: "demo",
      cached,
      folderId: cfg.folderId || null,
    };
  }

  const folderId = overrideFolderId ?? cfg.folderId;
  const { items, cached } = await getOrLoad(folderId, () =>
    fetchGalleryImages(folderId)
  );
  return { items, source: "google-drive", cached, folderId };
}

/** Force-evict the list cache (single folder or all). */
export function evictGalleryCache(folderId?: string): number {
  return evict(folderId);
}

/** Evict BOTH the list cache and the proxy byte cache. */
export function evictAllGalleryCaches(): { list: number; bytes: number } {
  return evictAll();
}

export function galleryCacheStats() {
  return cacheStats();
}

export function driveInitError(): string | null {
  return initError;
}

export function isDemoIdLocal(id: string): boolean {
  return isDemoId(id);
}

/* ------------------------------------------------------------------ */
/* Health check                                                        */
/* ------------------------------------------------------------------ */

/**
 * Returns a diagnostic snapshot for the admin panel + `/api/gallery/health`.
 * In LIVE mode optionally pings the Drive API with a 1-file list to verify
 * the service account can actually reach the folder.
 */
export async function healthCheck(opts?: {
  ping?: boolean;
}): Promise<GalleryHealthResponse> {
  const cfg = getGalleryConfig();
  const stats = cacheStats();

  const driveReady = !cfg.demoMode && !!getDriveClient() && !initError;
  let drivePing: "skipped" | "ok" | "failed" = "skipped";

  if (opts?.ping && !cfg.demoMode && getDriveClient()) {
    try {
      const escaped = cfg.folderId.replace(/'/g, "\\'");
      await getDriveClient()!.files.list({
        q: `'${escaped}' in parents and mimeType contains 'image/' and trashed = false`,
        pageSize: 1,
        fields: "files(id)",
        supportsAllDrives: true,
        includeItemsFromAllDrives: true,
      });
      drivePing = "ok";
    } catch (e) {
      initError = `Drive ping failed: ${(e as Error).message}`;
      drivePing = "failed";
    }
  }

  const status: "ok" | "degraded" | "error" = cfg.demoMode
    ? "ok"
    : driveReady && drivePing !== "failed"
    ? "ok"
    : driveReady
    ? "degraded"
    : "error";

  return {
    status,
    mode: cfg.demoMode ? "demo" : "google-drive",
    demoMode: cfg.demoMode,
    folderId: cfg.folderId || null,
    credentialsPresent: cfg.credentialsExist,
    credentialsPath: cfg.credentialsPath,
    driveReady,
    driveInitError: initError,
    cache: {
      size: stats.size,
      max: stats.max,
      ttlMs: stats.ttlMs,
    },
    cacheTtlMs: cfg.cacheTtlMs,
    checkedAt: new Date().toISOString(),
    drivePing,
  };
}

/* ------------------------------------------------------------------ */
/* Secure byte streaming for the proxy controller                      */
/* ------------------------------------------------------------------ */

export interface StreamResult {
  /** Full buffer (when small enough to cache) OR a streaming source. */
  buffer?: Buffer;
  stream?: NodeJS.ReadableStream;
  mimeType: string;
  size?: number;
}

/**
 * Returns image bytes for a single file, using a per-file byte cache so
 * repeat proxy hits don't re-hit the Drive API.
 *
 * - Demo ids (`demo-<n>`) read the local sample image.
 * - Real Drive ids stream `drive.files.get({ fileId, alt: 'media' })`.
 *
 * No Drive-internal URL is ever returned to the caller — only bytes.
 */
export async function getFileBytes(fileId: string): Promise<StreamResult> {
  // 1) Byte cache hit?
  const cached = getByteCacheEntry(fileId);
  if (cached) {
    return {
      buffer: cached.bytes,
      mimeType: cached.mimeType,
      size: cached.size,
    };
  }

  // 2) Demo file -> read from disk (and cache).
  if (isDemoId(fileId)) {
    const demo = demoFileForId(fileId);
    if (!demo || !demo.thumbnailLink) {
      throw new Error("Demo asset not found");
    }
    const abs = path.join(process.cwd(), "public", demo.thumbnailLink);
    if (!fs.existsSync(abs)) {
      throw new Error("Demo asset missing on disk");
    }
    const buf = fs.readFileSync(abs);
    setByteCacheEntry(fileId, {
      bytes: buf,
      mimeType: demo.mimeType,
      size: buf.length,
      fetchedAt: Date.now(),
    });
    return { buffer: buf, mimeType: demo.mimeType, size: buf.length };
  }

  // 3) Real Drive file -> fetch metadata + stream bytes into a buffer.
  const drive = getDriveClient();
  if (!drive) {
    throw new Error(initError ?? "Drive client unavailable");
  }

  const meta = await drive.files.get(
    { fileId, fields: "id, name, mimeType, size", supportsAllDrives: true },
    { responseType: "json" }
  );

  const mimeType = meta.data.mimeType ?? "image/jpeg";
  const size = meta.data.size ? Number(meta.data.size) : undefined;

  const media = await drive.files.get(
    { fileId, alt: "media", supportsAllDrives: true },
    { responseType: "stream" }
  );

  const stream = media.data as unknown as NodeJS.ReadableStream;

  // Buffer the stream so we can both cache it and answer range requests.
  const chunks: Buffer[] = [];
  await new Promise<void>((resolve, reject) => {
    stream.on("data", (c: Buffer) => chunks.push(c));
    stream.on("end", resolve);
    stream.on("error", reject);
  });
  const buf = Buffer.concat(chunks);

  setByteCacheEntry(fileId, {
    bytes: buf,
    mimeType,
    size: buf.length,
    fetchedAt: Date.now(),
  });

  return { buffer: buf, mimeType, size: buf.length };
}

/* ------------------------------------------------------------------ */
/* Image metadata (dimensions via sharp)                               */
/* ------------------------------------------------------------------ */

/**
 * Returns image dimensions + format for a file, using sharp to probe the
 * cached byte buffer. Results are cached per fileId so repeated lightbox
 * opens / card hovers don't re-probe. Falls back gracefully if sharp
 * can't parse the buffer.
 */
export async function getImageMeta(fileId: string): Promise<ImageMeta> {
  // 1) Meta cache hit?
  const cached = getMetaCacheEntry(fileId);
  if (cached) return cached;

  // 2) Get the bytes (reuses the byte cache / Drive fetch).
  const { buffer, mimeType, size } = await getFileBytes(fileId);

  try {
    const meta = await sharp(buffer).metadata();
    const result: ImageMeta = {
      width: meta.width ?? 0,
      height: meta.height ?? 0,
      type: meta.format ?? mimeType.split("/")[1] ?? "unknown",
      size: size ?? buffer.length,
    };
    setMetaCacheEntry(fileId, result);
    return result;
  } catch {
    // sharp couldn't parse — return a best-effort meta.
    const result: ImageMeta = {
      width: 0,
      height: 0,
      type: mimeType.split("/")[1] ?? "unknown",
      size: size ?? buffer.length,
    };
    setMetaCacheEntry(fileId, result);
    return result;
  }
}
