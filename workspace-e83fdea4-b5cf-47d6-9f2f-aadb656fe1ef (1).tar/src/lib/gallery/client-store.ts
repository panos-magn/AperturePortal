import fs from "node:fs";
import path from "node:path";
import { randomBytes } from "node:crypto";

/**
 * Client store — persists auto-generated access codes per client folder.
 *
 * Stored as a JSON file on disk (`clients.json` in the project root) so it
 * survives server restarts. Each client maps: folderId → { code, name, createdAt }.
 *
 * The admin dashboard reads this to show shareable links; the client gallery
 * validates the supplied code against this store.
 */

interface ClientRecord {
  code: string;
  name: string;
  createdAt: string;
}

const STORE_PATH = path.join(process.cwd(), "clients.json");

function readStore(): Record<string, ClientRecord> {
  try {
    if (!fs.existsSync(STORE_PATH)) return {};
    const raw = fs.readFileSync(STORE_PATH, "utf-8");
    return JSON.parse(raw) as Record<string, ClientRecord>;
  } catch {
    return {};
  }
}

function writeStore(data: Record<string, ClientRecord>): void {
  try {
    fs.writeFileSync(STORE_PATH, JSON.stringify(data, null, 2));
  } catch {
    /* ignore write errors (read-only FS etc.) */
  }
}

/** Generate a short, human-readable access code (8 chars, URL-safe). */
function generateCode(): string {
  return randomBytes(4).toString("hex");
}

/** Get all client records (admin dashboard). */
export function getAllClients(): Record<string, ClientRecord> {
  return readStore();
}

/** Get a single client by folderId. */
export function getClient(folderId: string): ClientRecord | undefined {
  return readStore()[folderId];
}

/** Ensure a client record exists for the given folder; create if missing.
 *  Returns the (possibly new) record. */
export function ensureClient(folderId: string, name: string): ClientRecord {
  const store = readStore();
  if (!store[folderId]) {
    const record: ClientRecord = {
      code: generateCode(),
      name,
      createdAt: new Date().toISOString(),
    };
    store[folderId] = record;
    writeStore(store);
    return record;
  }
  // Update the name if it changed.
  if (store[folderId].name !== name) {
    store[folderId] = { ...store[folderId], name };
    writeStore(store);
  }
  return store[folderId];
}

/** Regenerate the access code for a client. Returns the new record. */
export function regenerateCode(folderId: string): ClientRecord | undefined {
  const store = readStore();
  if (!store[folderId]) return undefined;
  store[folderId].code = generateCode();
  writeStore(store);
  return store[folderId];
}

/** Validate a client access code. Returns true if it matches. */
export function validateClientCode(folderId: string, code: string): boolean {
  const record = readStore()[folderId];
  if (!record) return false;
  return record.code === code;
}

/** Remove a client record (when a folder is deleted from Drive). */
export function removeClient(folderId: string): boolean {
  const store = readStore();
  if (!store[folderId]) return false;
  delete store[folderId];
  writeStore(store);
  return true;
}
