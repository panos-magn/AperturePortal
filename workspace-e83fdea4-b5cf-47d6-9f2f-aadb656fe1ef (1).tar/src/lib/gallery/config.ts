import path from "node:path";
import fs from "node:fs";

/**
 * Gallery runtime configuration.
 *
 * Reads environment variables that are the Next.js equivalent of the
 * Spring Boot `application.properties` entries:
 *   - google.drive.folder-id      -> GOOGLE_DRIVE_FOLDER_ID
 *   - google.credentials.path     -> GOOGLE_CREDENTIALS_PATH
 *   - gallery.cache.ttl-ms        -> GALLERY_CACHE_TTL_MS
 */
function readEnv(key: string, fallback = ""): string {
  const v = process.env[key];
  return v === undefined || v === "" ? fallback : v;
}

function projectRoot(): string {
  // Works in both `next dev` and standalone build.
  return process.cwd();
}

function resolveCredentialsPath(p: string): string {
  if (!p) return "";
  return path.isAbsolute(p) ? p : path.join(projectRoot(), p);
}

export interface GalleryConfig {
  folderId: string;
  credentialsPath: string;
  credentialsExist: boolean;
  cacheTtlMs: number;
  forceDemo: boolean;
  /** True when there are no usable credentials -> portal runs in DEMO mode. */
  demoMode: boolean;
}

let cached: GalleryConfig | null = null;

/**
 * Runtime override for the list-cache TTL (ms). When set via
 * `/api/gallery/config`, it takes precedence over the env value so operators
 * can tune the cache window without a redeploy. `null` = use env default.
 */
let runtimeTtlOverride: number | null = null;

const MIN_TTL_MS = 10_000; // 10s floor — anything lower is unreasonable
const MAX_TTL_MS = 24 * 60 * 60 * 1000; // 24h ceiling

export function getGalleryConfig(): GalleryConfig {
  if (cached) return cached;

  const folderId = readEnv("GOOGLE_DRIVE_FOLDER_ID");
  const rawPath = readEnv("GOOGLE_CREDENTIALS_PATH", "./credentials.json");
  const credentialsPath = resolveCredentialsPath(rawPath);
  const credentialsExist = fs.existsSync(credentialsPath);

  const ttlRaw = Number.parseInt(readEnv("GALLERY_CACHE_TTL_MS", "600000"), 10);
  const envTtl = Number.isFinite(ttlRaw) && ttlRaw > 0 ? ttlRaw : 600000;

  const forceDemo = readEnv("GALLERY_FORCE_DEMO", "").toLowerCase() === "true";
  const demoMode = forceDemo || !credentialsExist || !folderId;

  cached = {
    folderId,
    credentialsPath,
    credentialsExist,
    cacheTtlMs: runtimeTtlOverride ?? envTtl,
    forceDemo,
    demoMode,
  };
  return cached;
}

/**
 * Set a runtime TTL override (clamped to [10s, 24h]). Returns the resulting
 * effective TTL. Resets the in-memory config cache + list cache so the new
 * TTL is applied immediately.
 */
export function setRuntimeTtl(ms: number | null): number {
  const envTtl = Number.parseInt(
    readEnv("GALLERY_CACHE_TTL_MS", "600000"),
    10
  );
  const baseTtl =
    Number.isFinite(envTtl) && envTtl > 0 ? envTtl : 600000;

  if (ms === null || !Number.isFinite(ms)) {
    runtimeTtlOverride = null;
  } else {
    runtimeTtlOverride = Math.min(
      MAX_TTL_MS,
      Math.max(MIN_TTL_MS, Math.floor(ms))
    );
  }
  cached = null; // force re-read
  return runtimeTtlOverride ?? baseTtl;
}

export function getRuntimeTtl(): number | null {
  return runtimeTtlOverride;
}

export const TTL_LIMITS = { min: MIN_TTL_MS, max: MAX_TTL_MS };

/** Allow runtime reset (used by tests / cache-eviction tooling). */
export function resetGalleryConfig(): void {
  cached = null;
  runtimeTtlOverride = null;
}
