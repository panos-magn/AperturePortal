import type { DriveFileDto } from "./types";

/**
 * Demo dataset used when no Google Service Account credentials are present.
 *
 * Each `id` follows the `demo-<n>` convention which the secure image proxy
 * (`/api/gallery/images/[fileId]`) recognises and maps to a locally-stored
 * sample photo in `/public/gallery`. This lets the entire portal — list API,
 * proxy controller, grid + lightbox — run end-to-end without hitting Google.
 *
 * The byte stream still flows through the proxy endpoint exactly as it would
 * for real Drive files, so no Drive-internal URL is ever exposed.
 */
export const DEMO_FILES: DriveFileDto[] = [
  {
    id: "demo-1",
    name: "Alpine Lake — Golden Hour",
    createdTime: "2024-09-12T06:24:00.000Z",
    mimeType: "image/jpeg",
    size: "153499",
    thumbnailLink: "/gallery/mountain-lake.jpg",
    kind: "image",
  },
  {
    id: "demo-2",
    name: "Pacific Sunset",
    createdTime: "2024-09-10T19:42:00.000Z",
    mimeType: "image/jpeg",
    size: "192786",
    thumbnailLink: "/gallery/ocean-sunset.jpg",
    kind: "image",
  },
  {
    id: "demo-3",
    name: "Misty Forest Trail",
    createdTime: "2024-09-08T08:10:00.000Z",
    mimeType: "image/jpeg",
    size: "254305",
    thumbnailLink: "/gallery/forest-path.jpg",
    kind: "image",
  },
  {
    id: "demo-4",
    name: "Saharan Dunes — Blue Hour",
    createdTime: "2024-09-05T17:55:00.000Z",
    mimeType: "image/jpeg",
    size: "119935",
    thumbnailLink: "/gallery/desert-dunes.jpg",
    kind: "image",
  },
  {
    id: "demo-5",
    name: "City Skyline After Dark",
    createdTime: "2024-09-03T22:18:00.000Z",
    mimeType: "image/jpeg",
    size: "210440",
    thumbnailLink: "/gallery/city-skyline.jpg",
    kind: "image",
  },
  {
    id: "demo-6",
    name: "Aurora Over The Fjord",
    createdTime: "2024-08-30T23:58:00.000Z",
    mimeType: "image/jpeg",
    size: "228770",
    thumbnailLink: "/gallery/aurora-fjord.jpg",
    kind: "image",
  },
  {
    id: "demo-7",
    name: "Lavender Fields At Dawn",
    createdTime: "2024-08-27T05:36:00.000Z",
    mimeType: "image/jpeg",
    size: "176210",
    thumbnailLink: "/gallery/lavender-field.jpg",
    kind: "image",
  },
  {
    id: "demo-8",
    name: "Canyon Waterfall",
    createdTime: "2024-08-22T11:05:00.000Z",
    mimeType: "image/jpeg",
    size: "241880",
    thumbnailLink: "/gallery/waterfall-canyon.jpg",
    kind: "image",
  },
];

/** Resolve a demo id (e.g. `demo-3`) to the on-disk sample image path. */
export function demoFileForId(id: string): DriveFileDto | undefined {
  return DEMO_FILES.find((f) => f.id === id);
}

export function isDemoId(id: string): boolean {
  return /^demo-\d+$/.test(id);
}
