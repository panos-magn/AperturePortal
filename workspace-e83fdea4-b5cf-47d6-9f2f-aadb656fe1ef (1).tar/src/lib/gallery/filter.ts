import type { DriveFileDto } from "./types";
import type { SortKey } from "@/components/gallery/gallery-toolbar";

/**
 * Client-side filtering + sorting helpers for the gallery.
 *
 * The Drive API already returns images newest-first, but once they are
 * cached on the server the client can freely re-order / filter the list
 * without another round-trip.
 */

export function filterItems(items: DriveFileDto[], query: string): DriveFileDto[] {
  const q = query.trim().toLowerCase();
  if (!q) return items;
  return items.filter((it) => it.name.toLowerCase().includes(q));
}

export function sortItems(items: DriveFileDto[], sort: SortKey): DriveFileDto[] {
  const copy = [...items];
  switch (sort) {
    case "date-desc":
      return copy.sort((a, b) => b.createdTime.localeCompare(a.createdTime));
    case "date-asc":
      return copy.sort((a, b) => a.createdTime.localeCompare(b.createdTime));
    case "name-asc":
      return copy.sort((a, b) => a.name.localeCompare(b.name));
    case "name-desc":
      return copy.sort((a, b) => b.name.localeCompare(a.name));
    case "size-desc":
      return copy.sort(
        (a, b) => (Number(b.size) || 0) - (Number(a.size) || 0)
      );
    case "size-asc":
      return copy.sort(
        (a, b) => (Number(a.size) || 0) - (Number(b.size) || 0)
      );
    default:
      return copy;
  }
}

export function filterAndSort(
  items: DriveFileDto[],
  query: string,
  sort: SortKey
): DriveFileDto[] {
  return sortItems(filterItems(items, query), sort);
}
