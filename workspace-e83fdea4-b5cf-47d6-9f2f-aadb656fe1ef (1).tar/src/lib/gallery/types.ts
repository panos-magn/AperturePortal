/**
 * DriveFileDto
 *
 * Mirrors the Java `DriveFileDto` record described in the spec.
 * Extracted fields: File ID, Name, CreatedTime, ThumbnailLink,
 * plus mimeType/size used by the secure proxy & UI.
 */
export interface DriveFileDto {
  id: string;
  name: string;
  createdTime: string; // ISO 8601
  thumbnailLink?: string;
  mimeType: string;
  size?: string;
  /** Derived from mimeType: "image" or "video". Used by the UI to pick
   *  <img> vs <video> in the grid + lightbox. */
  kind: "image" | "video";
}

export type GallerySource = "google-drive" | "demo";

export interface GalleryListResponse {
  items: DriveFileDto[];
  source: GallerySource;
  demo: boolean;
  cached: boolean;
  cacheTtlMs: number;
  folderId: string | null;
  fetchedAt: string; // ISO 8601
  count: number;
  /** Present when LIVE mode is configured but the Drive client failed to init. */
  driveInitError?: string | null;
  /** Folder id recognised but credentials missing -> actionable hint. */
  credentialsPresent?: boolean;
}

export interface GalleryHealthResponse {
  status: "ok" | "degraded" | "error";
  mode: GallerySource;
  demoMode: boolean;
  folderId: string | null;
  credentialsPresent: boolean;
  credentialsPath: string;
  driveReady: boolean;
  driveInitError: string | null;
  cache: {
    size: number;
    max: number;
    ttlMs: number;
  };
  cacheTtlMs: number;
  checkedAt: string; // ISO 8601
  /** Optional: a tiny ping to verify the Drive client can actually list. */
  drivePing?: "skipped" | "ok" | "failed";
}

export interface CacheStatsResponse {
  size: number;
  max: number;
  ttlMs: number;
  calculatedSize: number;
}

export interface CacheEvictResponse {
  ok: boolean;
  evicted: number;
  stats: CacheStatsResponse;
  evictedAt: string;
}
