"use client";

import { useCallback, useSyncExternalStore } from "react";

/**
 * useLocalStorage — SSR-safe persisted state built on useSyncExternalStore.
 *
 * `useSyncExternalStore` is the React-recommended primitive for subscribing
 * to an external store (localStorage + cross-tab `storage` events). It avoids
 * the setState-in-effect anti-pattern and gives us a stable, hydration-safe
 * read.
 *
 * - On the server it returns `initialValue`.
 * - On the client it reads localStorage lazily on first subscription.
 * - Writes go through `setValue`, which updates storage and notifies
 *   subscribers (same-tab) — `storage` events cover cross-tab sync.
 *
 * The store itself is module-level (singleton per storage key) so every
 * component using the same key shares the same cache + listener set.
 */

interface StoreEntry {
  value: unknown;
  listeners: Set<() => void>;
  parsed: boolean;
}

const store = new Map<string, StoreEntry>();

function getEntry(key: string, initialValue: unknown): StoreEntry {
  let entry = store.get(key);
  if (!entry) {
    entry = { value: initialValue, listeners: new Set(), parsed: false };
    store.set(key, entry);
  }
  return entry;
}

function readFromStorage(key: string, initialValue: unknown): unknown {
  try {
    const raw = window.localStorage.getItem(key);
    if (raw !== null) return JSON.parse(raw);
  } catch {
    /* ignore parse / unavailable errors */
  }
  return initialValue;
}

// One global storage-event listener dispatches to all interested entries.
if (typeof window !== "undefined") {
  window.addEventListener("storage", (e) => {
    if (!e.key) return;
    const entry = store.get(e.key);
    if (!entry) return;
    // Force a re-read on next snapshot.
    entry.parsed = false;
    entry.listeners.forEach((fn) => fn());
  });
}

export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((prev: T) => T)) => void] {
  const subscribe = useCallback(
    (onStoreChange: () => void) => {
      const entry = getEntry(key, initialValue);
      entry.listeners.add(onStoreChange);
      return () => {
        entry.listeners.delete(onStoreChange);
      };
    },
    [key, initialValue]
  );

  const getSnapshot = useCallback((): T => {
    const entry = getEntry(key, initialValue) as StoreEntry;
    if (!entry.parsed) {
      entry.value = readFromStorage(key, initialValue);
      entry.parsed = true;
    }
    return entry.value as T;
  }, [key, initialValue]);

  const getServerSnapshot = useCallback((): T => initialValue, [initialValue]);

  const value = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const setValue = useCallback(
    (next: T | ((prev: T) => T)) => {
      const entry = getEntry(key, initialValue) as StoreEntry;
      const prev = (entry.parsed ? entry.value : readFromStorage(key, initialValue)) as T;
      const resolved =
        typeof next === "function" ? (next as (p: T) => T)(prev) : next;
      entry.value = resolved;
      entry.parsed = true;
      try {
        window.localStorage.setItem(key, JSON.stringify(resolved));
      } catch {
        /* ignore quota / unavailable errors */
      }
      entry.listeners.forEach((fn) => fn());
    },
    [key, initialValue]
  );

  return [value, setValue];
}
