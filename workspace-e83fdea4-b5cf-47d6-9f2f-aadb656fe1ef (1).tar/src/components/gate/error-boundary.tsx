"use client";

import { Component, type ReactNode } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * ErrorBoundary — catches render-time errors in the gallery subtree and
 * shows a friendly fallback instead of a blank screen. The user can retry
 * by clicking the reload button.
 */
export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen flex-col items-center justify-center bg-neutral-950 px-4 text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-500/10 ring-1 ring-rose-400/30">
            <AlertTriangle className="h-7 w-7 text-rose-400" />
          </div>
          <h1 className="text-lg font-semibold text-white">
            Something went wrong
          </h1>
          <p className="mt-2 max-w-sm text-sm text-neutral-400">
            An unexpected error occurred while rendering the gallery. Try
            reloading — your preferences are saved.
          </p>
          {this.state.error?.message ? (
            <pre className="mt-3 max-w-md overflow-x-auto rounded-lg bg-neutral-900 p-3 text-left text-[11px] text-neutral-500 ring-1 ring-neutral-800">
              {this.state.error.message}
            </pre>
          ) : null}
          <button
            onClick={() => window.location.reload()}
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-black transition hover:bg-emerald-400"
          >
            <RefreshCw className="h-4 w-4" />
            Reload
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
