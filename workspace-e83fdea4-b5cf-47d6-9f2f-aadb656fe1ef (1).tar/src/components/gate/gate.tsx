"use client";

import { useCallback, useEffect, useState } from "react";
import { Aperture, Lock, Loader2, ShieldCheck, ArrowRight } from "lucide-react";

interface GateProps {
  children: React.ReactNode;
}

/**
 * Gate — wraps the entire app. Checks `/api/auth` for an existing session
 * cookie. If authenticated (or if no PIN is configured = open mode), renders
 * the children. Otherwise shows a clean login screen.
 *
 * The PIN is validated server-side against the ACCESS_PIN env var; the
 * client never sees the correct value.
 */
export function Gate({ children }: GateProps) {
  const [status, setStatus] = useState<"loading" | "authed" | "unauthed">("loading");
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const check = useCallback(async () => {
    try {
      const res = await fetch("/api/auth", { cache: "no-store" });
      const j = await res.json();
      if (j.authenticated) {
        setStatus("authed");
      } else {
        setStatus("unauthed");
      }
    } catch {
      setStatus("unauthed");
    }
  }, []);

  useEffect(() => {
    check();
  }, [check]);

  const submit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setSubmitting(true);
      setError(null);
      try {
        const res = await fetch("/api/auth", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pin }),
        });
        if (res.ok) {
          setStatus("authed");
          setPin("");
        } else {
          setError("Incorrect access code. Please try again.");
        }
      } catch {
        setError("Something went wrong. Please try again.");
      } finally {
        setSubmitting(false);
      }
    },
    [pin]
  );

  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-neutral-950">
        <Loader2 className="h-7 w-7 animate-spin text-emerald-400" />
      </div>
    );
  }

  if (status === "authed") {
    return <>{children}</>;
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-neutral-950 px-4">
      {/* Aurora background */}
      <div className="aurora-bg absolute inset-0" />

      <div className="relative w-full max-w-sm">
        {/* Logo + title */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 text-black shadow-lg shadow-emerald-500/20">
            <Aperture className="h-7 w-7" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-white">
            Aperture
          </h1>
          <p className="mt-1 text-sm text-neutral-400">
            Client Media Portal
          </p>
        </div>

        {/* Login card */}
        <form
          onSubmit={submit}
          className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-6 backdrop-blur-sm"
        >
          <div className="mb-4 flex items-center gap-2 text-sm text-neutral-300">
            <Lock className="h-4 w-4 text-emerald-400" />
            <span>Enter your access code</span>
          </div>

          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="Access code"
            autoFocus
            autoComplete="current-password"
            className="w-full rounded-lg border border-neutral-700 bg-neutral-950/60 px-4 py-2.5 text-sm text-neutral-100 placeholder:text-neutral-500 transition focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
          />

          {error ? (
            <p className="mt-2 text-xs text-rose-400">{error}</p>
          ) : null}

          <button
            type="submit"
            disabled={submitting || !pin}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-black transition hover:bg-emerald-400 disabled:opacity-40"
          >
            {submitting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                Enter
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
        </form>

        {/* Footer note */}
        <div className="mt-6 flex items-center justify-center gap-1.5 text-xs text-neutral-500">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-500/60" />
          <span>Secure · Server-proxied · No Drive URLs exposed</span>
        </div>
      </div>
    </div>
  );
}
