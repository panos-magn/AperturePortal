"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Aperture,
  RefreshCw,
  Copy,
  Check,
  ExternalLink,
  KeyRound,
  Loader2,
  FolderOpen,
  Image as ImageIcon,
  Film,
  LogOut,
  AlertTriangle,
} from "lucide-react";

interface Client {
  id: string;
  name: string;
  createdTime: string;
  code: string;
  codeCreatedAt: string;
}

interface AdminDashboardProps {
  onLogout: () => void;
}

function copyToClipboard(text: string): void {
  navigator.clipboard?.writeText(text).catch(() => {});
}

/**
 * AdminDashboard — the user's management view. Lists all client subfolders
 * from the root Drive folder, each with an auto-generated shareable link +
 * access code. Supports regenerating codes and copying links.
 */
export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null);
  const [mediaCounts, setMediaCounts] = useState<Record<string, number>>({});

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/clients", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const j = await res.json();
      setClients(j.clients || []);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // Fetch media counts per client (in parallel, but sequentially to respect
  // Drive API rate limits — only fetch counts for the first render).
  useEffect(() => {
    if (clients.length === 0) return;
    let cancelled = false;
    (async () => {
      const counts: Record<string, number> = {};
      for (const c of clients) {
        try {
          const res = await fetch(`/api/gallery?folderId=${c.id}`, {
            cache: "no-store",
          });
          if (res.ok) {
            const j = await res.json();
            counts[c.id] = j.count ?? 0;
            if (!cancelled) setMediaCounts({ ...counts });
          }
        } catch {
          /* skip */
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [clients]);

  const regenerate = useCallback(
    async (folderId: string) => {
      setRegeneratingId(folderId);
      try {
        const res = await fetch("/api/clients", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ folderId, action: "regenerate" }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = await res.json();
        setClients((prev) =>
          prev.map((c) =>
            c.id === folderId ? { ...c, code: j.code } : c
          )
        );
      } catch {
        /* ignore */
      } finally {
        setRegeneratingId(null);
      }
    },
    []
  );

  const copyLink = useCallback((clientId: string, code: string) => {
    const origin = window.location.origin;
    const link = `${origin}/?c=${clientId}&code=${code}`;
    copyToClipboard(link);
    setCopiedId(clientId);
    setTimeout(() => setCopiedId(null), 2000);
  }, []);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-neutral-800/80 bg-neutral-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-400 to-teal-500 text-black shadow-lg shadow-emerald-500/20">
              <Aperture className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <h1 className="text-sm font-semibold tracking-tight text-white sm:text-base">
                Aperture
              </h1>
              <p className="text-[11px] text-neutral-400">
                Admin Dashboard
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={load}
              disabled={loading}
              className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-xs font-medium text-neutral-100 ring-1 ring-neutral-700 transition hover:bg-neutral-700 disabled:opacity-50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
            <button
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-xs font-medium text-neutral-100 ring-1 ring-neutral-700 transition hover:bg-neutral-700"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-white sm:text-2xl">
            Clients
          </h2>
          <p className="mt-1 text-sm text-neutral-400">
            Each Drive subfolder is a client. Share the link + access code so
            they can view only their media.
          </p>
        </div>

        {error ? (
          <div className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-200">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <p className="font-medium">Couldn’t load clients</p>
              <p className="mt-1 text-amber-200/80">{error}</p>
            </div>
          </div>
        ) : null}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-neutral-400">
            <Loader2 className="mb-3 h-7 w-7 animate-spin text-emerald-400" />
            <p className="text-sm">Loading clients…</p>
          </div>
        ) : clients.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-neutral-800 bg-neutral-900/40 py-20 text-center">
            <FolderOpen className="mb-3 h-10 w-10 text-neutral-600" />
            <p className="text-sm font-medium text-neutral-300">
              No client folders found
            </p>
            <p className="mt-1 max-w-sm text-xs text-neutral-500">
              Create subfolders inside your root Drive folder — each one
              becomes a client gallery.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {clients.map((c) => {
              const count = mediaCounts[c.id];
              const link = `${typeof window !== "undefined" ? window.location.origin : ""}/?c=${c.id}&code=${c.code}`;
              return (
                <div
                  key={c.id}
                  className="rounded-2xl border border-neutral-800 bg-neutral-900/50 p-5 transition hover:border-neutral-700"
                >
                  <div className="mb-4 flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate text-base font-semibold text-white">
                        {c.name}
                      </h3>
                      <p className="mt-0.5 flex items-center gap-2 text-xs text-neutral-500">
                        {count !== undefined ? (
                          <span className="inline-flex items-center gap-1">
                            <ImageIcon className="h-3 w-3" />
                            {count} item{count === 1 ? "" : "s"}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1">
                            <Loader2 className="h-3 w-3 animate-spin" />
                            counting…
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 rounded-lg bg-sky-500/10 px-2 py-1 text-[11px] font-medium text-sky-300 ring-1 ring-sky-400/20">
                      <KeyRound className="h-3 w-3" />
                      <code className="font-mono">{c.code}</code>
                    </div>
                  </div>

                  {/* Shareable link */}
                  <div className="mb-3">
                    <label className="mb-1 block text-[10px] uppercase tracking-wide text-neutral-500">
                      Client link
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        readOnly
                        value={link}
                        onClick={(e) => (e.target as HTMLInputElement).select()}
                        className="w-full truncate rounded-lg border border-neutral-700 bg-neutral-950/60 px-3 py-1.5 text-xs text-neutral-300 focus:outline-none"
                      />
                      <button
                        onClick={() => copyLink(c.id, c.code)}
                        className="inline-flex shrink-0 items-center gap-1 rounded-lg bg-neutral-800 px-2.5 py-1.5 text-[11px] font-medium text-neutral-200 ring-1 ring-neutral-700 transition hover:bg-neutral-700"
                      >
                        {copiedId === c.id ? (
                          <>
                            <Check className="h-3.5 w-3.5 text-emerald-400" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="h-3.5 w-3.5" />
                            Copy
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <a
                      href={link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500/90 px-3 py-1.5 text-[11px] font-medium text-black transition hover:bg-emerald-400"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      Open
                    </a>
                    <button
                      onClick={() => regenerate(c.id)}
                      disabled={regeneratingId === c.id}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-[11px] font-medium text-neutral-200 ring-1 ring-neutral-700 transition hover:bg-neutral-700 disabled:opacity-50"
                    >
                      <KeyRound className="h-3.5 w-3.5" />
                      {regeneratingId === c.id ? "Regenerating…" : "New code"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
