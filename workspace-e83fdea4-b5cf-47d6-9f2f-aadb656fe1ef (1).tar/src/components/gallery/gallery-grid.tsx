"use client";

import { forwardRef, useImperativeHandle, useRef, useState } from "react";
import { ImageOff, Calendar, LayoutGrid, Rows3, Search, Star, CheckSquare, Square, Play, Film } from "lucide-react";
import type { DriveFileDto } from "@/lib/gallery/types";
import { Lightbox, type SlideshowSpeed, type KenBurnsDirection } from "./lightbox";
import { StarButton } from "./star-button";
import { DimensionBadge } from "./dimension-badge";
import { cn } from "@/lib/utils";

export interface GalleryGridHandle {
  /** Open the lightbox at the image with the given id (if present). */
  openById: (id: string) => void;
}

interface GalleryGridProps {
  items: DriveFileDto[];
  layout: "grid" | "masonry";
  /** When true, an active search query produced zero matches. */
  hasQuery?: boolean;
  /** Slideshow speed (ms) forwarded to the Lightbox. */
  slideshowSpeed?: SlideshowSpeed;
  onSlideshowSpeedChange?: (ms: SlideshowSpeed) => void;
  /** Notify parent when an image is opened (for the recently-viewed rail). */
  onImageView?: (id: string) => void;
  /** Favourite file ids (for star state + lightbox). */
  favourites?: string[];
  onToggleFavourite?: (id: string) => void;
  /** Multi-select mode: when true, cards show a checkbox and clicking toggles
   *  selection instead of opening the lightbox. */
  selectMode?: boolean;
  selectedIds?: string[];
  onToggleSelect?: (id: string) => void;
  /** Shift-click range selection: select all items from the anchor to `index`. */
  onRangeSelect?: (index: number) => void;
  /** Ken Burns direction (zoom-in vs zoom-out) forwarded to the Lightbox. */
  kenBurnsDirection?: KenBurnsDirection;
  onKenBurnsDirectionChange?: (d: KenBurnsDirection) => void;
}

function proxyUrl(id: string) {
  return `/api/gallery/images/${id}`;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return iso;
  }
}

export const GalleryGrid = forwardRef<GalleryGridHandle, GalleryGridProps>(
  function GalleryGrid({
    items,
    layout,
    hasQuery,
    slideshowSpeed,
    onSlideshowSpeedChange,
    onImageView,
    favourites,
    onToggleFavourite,
    selectMode,
    selectedIds,
    onToggleSelect,
    onRangeSelect,
    kenBurnsDirection,
    onKenBurnsDirectionChange,
  }: GalleryGridProps, ref) {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  // Loaded markers accumulate per file-id. New ids (e.g. freshly-uploaded
  // Drive images) naturally show the shimmer until their <img> fires onLoad,
  // without needing an effect to reset the set.
  const [loadedIds, setLoadedIds] = useState<Set<string>>(new Set());

  // Expose an imperative openById for the recently-viewed rail.
  useImperativeHandle(
    ref,
    () => ({
      openById: (id: string) => {
        const idx = items.findIndex((it) => it.id === id);
        if (idx >= 0) {
          setLightboxIndex(idx);
          onImageView?.(id);
        }
      },
    }),
    [items, onImageView]
  );

  const openAt = (i: number) => {
    setLightboxIndex(i);
    onImageView?.(items[i]?.id);
  };
  const close = () => setLightboxIndex(null);
  const prev = () =>
    setLightboxIndex((i) => {
      if (i === null) return i;
      const n = (i - 1 + items.length) % items.length;
      onImageView?.(items[n]?.id);
      return n;
    });
  const next = () =>
    setLightboxIndex((i) => {
      if (i === null) return i;
      const n = (i + 1) % items.length;
      onImageView?.(items[n]?.id);
      return n;
    });
  const jumpTo = (i: number) => {
    setLightboxIndex(i);
    onImageView?.(items[i]?.id);
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-neutral-800 bg-neutral-900/40 py-20 text-center">
        {hasQuery ? (
          <>
            <Search className="mb-3 h-10 w-10 text-neutral-600" />
            <p className="text-sm font-medium text-neutral-300">
              No images match your search
            </p>
            <p className="mt-1 max-w-sm text-xs text-neutral-500">
              Try a different keyword, or clear the search to see all images.
            </p>
          </>
        ) : (
          <>
            <ImageOff className="mb-3 h-10 w-10 text-neutral-600" />
            <p className="text-sm font-medium text-neutral-300">No images found</p>
            <p className="mt-1 max-w-sm text-xs text-neutral-500">
              The configured Google Drive folder is empty, or the service
              account does not have access yet. Upload images to the folder and
              refresh.
            </p>
          </>
        )}
      </div>
    );
  }

  const onLoaded = (id: string) =>
    setLoadedIds((prev) => {
      if (prev.has(id)) return prev;
      const next = new Set(prev);
      next.add(id);
      return next;
    });

  return (
    <>
      {layout === "masonry" ? (
        <div className="columns-1 gap-4 sm:columns-2 md:columns-3 lg:columns-4 [&>*]:mb-4 [&>*]:break-inside-avoid">
          {items.map((item, i) => (
            <GalleryCard
              key={item.id}
              item={item}
              index={i}
              masonry
              loaded={loadedIds.has(item.id)}
              onLoad={() => onLoaded(item.id)}
              onClick={(shiftKey) =>
                selectMode
                  ? shiftKey
                    ? onRangeSelect?.(i)
                    : onToggleSelect?.(item.id)
                  : openAt(i)
              }
              isFavourite={favourites?.includes(item.id)}
              onToggleFavourite={
                onToggleFavourite ? () => onToggleFavourite(item.id) : undefined
              }
              selectMode={selectMode}
              selected={selectedIds?.includes(item.id)}
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {items.map((item, i) => (
            <GalleryCard
              key={item.id}
              item={item}
              index={i}
              loaded={loadedIds.has(item.id)}
              onLoad={() => onLoaded(item.id)}
              onClick={(shiftKey) =>
                selectMode
                  ? shiftKey
                    ? onRangeSelect?.(i)
                    : onToggleSelect?.(item.id)
                  : openAt(i)
              }
              isFavourite={favourites?.includes(item.id)}
              onToggleFavourite={
                onToggleFavourite ? () => onToggleFavourite(item.id) : undefined
              }
              selectMode={selectMode}
              selected={selectedIds?.includes(item.id)}
            />
          ))}
        </div>
      )}

      {lightboxIndex !== null && (
        <Lightbox
          items={items}
          index={lightboxIndex}
          onClose={close}
          onPrev={prev}
          onNext={next}
          onJump={jumpTo}
          slideshowSpeed={slideshowSpeed}
          onSlideshowSpeedChange={onSlideshowSpeedChange}
          kenBurnsDirection={kenBurnsDirection}
          onKenBurnsDirectionChange={onKenBurnsDirectionChange}
          isFavourite={
            favourites?.includes(items[lightboxIndex]?.id) ?? false
          }
          onToggleFavourite={
            onToggleFavourite
              ? () => onToggleFavourite(items[lightboxIndex]?.id)
              : undefined
          }
        />
      )}
    </>
  );
  }
);

interface GalleryCardProps {
  item: DriveFileDto;
  index: number;
  masonry?: boolean;
  loaded: boolean;
  onLoad: () => void;
  onClick: (shiftKey: boolean) => void;
  isFavourite?: boolean;
  onToggleFavourite?: () => void;
  selectMode?: boolean;
  selected?: boolean;
}

function GalleryCard({
  item,
  index,
  masonry,
  loaded,
  onLoad,
  onClick,
  isFavourite,
  onToggleFavourite,
  selectMode,
  selected,
}: GalleryCardProps) {
  const aspectClass = masonry ? "" : "aspect-[4/3]";
  return (
    <button
      onClick={(e) => onClick(e.shiftKey || e.getModifierState("Shift"))}
      className={cn(
        "group relative block w-full overflow-hidden rounded-xl bg-neutral-900 text-left ring-1 transition",
        selected
          ? "ring-2 ring-emerald-400"
          : isFavourite
          ? "ring-1 ring-amber-400/50 hover:ring-2 hover:ring-amber-400/70"
          : "ring-neutral-800 hover:ring-2 hover:ring-emerald-400/70",
        "focus:outline-none focus:ring-2 focus:ring-emerald-400/70",
        loaded ? "animate-in fade-in duration-500" : ""
      )}
      aria-label={
        selectMode
          ? `${selected ? "Deselect" : "Select"} ${item.name}`
          : `Open ${item.name} in lightbox`
      }
      aria-pressed={selectMode ? !!selected : undefined}
    >
      <div
        className={cn(
          "relative w-full overflow-hidden",
          aspectClass,
          masonry ? "" : "h-full"
        )}
      >
        {!loaded ? (
          <div className="absolute inset-0 bg-gradient-to-br from-neutral-800/60 via-neutral-900 to-neutral-800/60">
            <div className="shimmer absolute inset-0" />
          </div>
        ) : null}
        {item.kind === "video" ? (
          <video
            src={proxyUrl(item.id)}
            poster={item.thumbnailLink}
            muted
            playsInline
            preload="metadata"
            onLoadedData={onLoad}
            className={cn(
              "h-full w-full object-cover transition duration-500 ease-out group-hover:scale-[1.04]",
              masonry ? "block" : "",
              loaded ? "opacity-100" : "opacity-0"
            )}
          />
        ) : (
          <img
            src={proxyUrl(item.id)}
            alt={item.name}
            loading="lazy"
            decoding="async"
            onLoad={onLoad}
            className={cn(
              "h-full w-full object-cover transition duration-500 ease-out group-hover:scale-[1.04]",
              masonry ? "block" : "",
              loaded ? "opacity-100" : "opacity-0"
            )}
          />
        )}
        {/* Video play overlay */}
        {item.kind === "video" ? (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black/55 text-white ring-1 ring-white/30 backdrop-blur-sm transition group-hover:scale-110 group-hover:bg-emerald-500/80">
              <Play className="ml-0.5 h-5 w-5 fill-current" />
            </div>
          </div>
        ) : null}
      </div>

      {/* Bottom gradient + caption */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-3 pt-8 opacity-90 transition group-hover:opacity-100">
        <p className="truncate text-sm font-medium text-white">{item.name}</p>
        <p className="mt-0.5 flex items-center gap-1 text-[11px] text-neutral-300">
          <Calendar className="h-3 w-3" />
          {formatDate(item.createdTime)}
        </p>
      </div>

      {/* Corner index badge (hidden in select mode to make room for checkbox) */}
      {!selectMode ? (
        <div className="absolute right-2 top-2 flex items-center gap-1">
          {item.kind === "video" ? (
            <span className="inline-flex items-center gap-1 rounded-md bg-sky-500/80 px-1.5 py-0.5 text-[9px] font-bold uppercase text-white ring-1 ring-white/10 backdrop-blur-sm">
              <Film className="h-2.5 w-2.5" />
              Video
            </span>
          ) : null}
          <span className="rounded-md bg-black/55 px-1.5 py-0.5 font-mono text-[10px] text-neutral-200 ring-1 ring-white/10 backdrop-blur-sm">
            {String(index + 1).padStart(2, "0")}
          </span>
        </div>
      ) : (
        <div
          className={`absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-md ring-1 backdrop-blur-sm transition ${
            selected
              ? "bg-emerald-500 text-black ring-emerald-400"
              : "bg-black/55 text-neutral-300 ring-white/20"
          }`}
          aria-hidden
        >
          {selected ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
        </div>
      )}

      {/* Dimension badge (bottom-left, hover-revealed) */}
      <div className="absolute bottom-2 left-2 opacity-0 transition group-hover:opacity-100">
        <DimensionBadge fileId={item.id} kind={item.kind} />
      </div>

      {/* Favourite star (top-left) */}
      {onToggleFavourite ? (
        <div className="absolute left-2 top-2 opacity-0 transition group-hover:opacity-100 focus-within:opacity-100">
          <StarButton
            active={!!isFavourite}
            onToggle={onToggleFavourite}
            size="sm"
          />
        </div>
      ) : null}

      {/* Favourite indicator (always visible when favourited, even without hover) */}
      {isFavourite ? (
        <div className="pointer-events-none absolute left-2 top-2 group-hover:opacity-0">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-400/15 text-amber-300 ring-1 ring-amber-400/40 backdrop-blur-sm">
            <Star className="h-3.5 w-3.5 fill-amber-300" />
          </div>
        </div>
      ) : null}
    </button>
  );
}

/** Toolbar with the layout toggle (grid / masonry). */
export function LayoutToggle({
  layout,
  onChange,
}: {
  layout: "grid" | "masonry";
  onChange: (l: "grid" | "masonry") => void;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  return (
    <div
      ref={ref}
      className="inline-flex items-center rounded-lg bg-neutral-800/80 p-0.5 ring-1 ring-neutral-700"
      role="group"
      aria-label="Gallery layout"
    >
      <ToggleBtn
        active={layout === "grid"}
        onClick={() => onChange("grid")}
        label="Grid"
      >
        <LayoutGrid className="h-3.5 w-3.5" />
      </ToggleBtn>
      <ToggleBtn
        active={layout === "masonry"}
        onClick={() => onChange("masonry")}
        label="Masonry"
      >
        <Rows3 className="h-3.5 w-3.5" />
      </ToggleBtn>
    </div>
  );
}

function ToggleBtn({
  active,
  onClick,
  label,
  children,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      title={label}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-[11px] font-medium transition",
        active
          ? "bg-neutral-950 text-emerald-300 shadow-sm"
          : "text-neutral-400 hover:text-neutral-200"
      )}
    >
      {children}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}
