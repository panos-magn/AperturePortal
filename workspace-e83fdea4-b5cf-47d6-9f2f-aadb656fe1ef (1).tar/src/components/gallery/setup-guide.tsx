"use client";

import { useState } from "react";
import {
  ChevronDown,
  KeyRound,
  FolderOpen,
  FileJson,
  Settings2,
  CheckCircle2,
  Circle,
  ExternalLink,
  Terminal,
} from "lucide-react";
import { useLocalStorage } from "@/hooks/use-local-storage";

const STEPS: {
  icon: React.ReactNode;
  title: string;
  body: React.ReactNode;
}[] = [
  {
    icon: <KeyRound className="h-4 w-4" />,
    title: "1 · Create a Google Service Account",
    body: (
      <>
        In Google Cloud Console, create (or pick) a project, then navigate to
        <span className="font-mono text-neutral-300"> IAM &amp; Admin → Service Accounts → Create</span>.
        Give it a name like <span className="font-mono text-neutral-300">aperture-gallery</span>. No
        user access is required — this is a headless account.
      </>
    ),
  },
  {
    icon: <FileJson className="h-4 w-4" />,
    title: "2 · Download the JSON key",
    body: (
      <>
        Open the service account → <span className="font-mono text-neutral-300">Keys → Add Key →
        Create new key → JSON</span>. Save the downloaded file as
        <span className="font-mono text-neutral-300"> credentials.json</span> in the project root
        (the path configured via <span className="font-mono text-neutral-300">GOOGLE_CREDENTIALS_PATH</span>).
      </>
    ),
  },
  {
    icon: <FolderOpen className="h-4 w-4" />,
    title: "3 · Share the Drive folder with the service account",
    body: (
      <>
        Copy the service account email (looks like
        <span className="font-mono text-neutral-300"> aperture-gallery@&lt;project&gt;.iam.gserviceaccount.com</span>),
        then in Google Drive right-click the gallery folder →
        <span className="font-mono text-neutral-300"> Share</span> → paste the email → grant
        <span className="font-mono text-neutral-300"> Viewer</span> access.
      </>
    ),
  },
  {
    icon: <Settings2 className="h-4 w-4" />,
    title: "4 · Configure environment",
    body: (
      <>
        Set the two env vars (or edit <span className="font-mono text-neutral-300">.env</span>):
        <pre className="mt-2 overflow-x-auto rounded-lg bg-neutral-950/80 p-3 font-mono text-[11px] text-emerald-300 ring-1 ring-neutral-800">
{`GOOGLE_DRIVE_FOLDER_ID=<folder id from the Drive URL>
GOOGLE_CREDENTIALS_PATH=./credentials.json`}
        </pre>
        The folder ID is the long string in the Drive URL after
        <span className="font-mono text-neutral-300"> /folders/</span>.
      </>
    ),
  },
  {
    icon: <Terminal className="h-4 w-4" />,
    title: "5 · Restart & verify",
    body: (
      <>
        Restart the server. The header badge flips from
        <span className="ml-1 rounded bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-medium text-amber-300">DEMO</span>
        to
        <span className="ml-1 rounded bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-medium text-emerald-300">LIVE · DRIVE</span>.
        Open the <span className="font-mono text-neutral-300">System &amp; Cache</span> panel and
        click <span className="font-mono text-neutral-300">Ping Drive</span> to confirm access.
      </>
    ),
  },
];

export function SetupGuide() {
  const [open, setOpen] = useLocalStorage<boolean>(
    "aperture.setupGuideOpen",
    false
  );

  return (
    <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left sm:px-5"
        aria-expanded={open}
      >
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-500/10 ring-1 ring-sky-400/20">
            <KeyRound className="h-4 w-4 text-sky-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">
              Connect to Google Drive
            </h3>
            <p className="text-[11px] text-neutral-500">
              5 steps to switch from Demo to Live mode
            </p>
          </div>
        </div>
        <ChevronDown
          className={`h-4 w-4 shrink-0 text-neutral-400 transition-transform ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>

      {open ? (
        <div className="border-t border-neutral-800 px-4 py-4 sm:px-5">
          <ol className="space-y-4">
            {STEPS.map((s, i) => (
              <li key={i} className="flex gap-3">
                <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-400/20">
                  {s.icon}
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-neutral-100">
                    {s.title}
                  </p>
                  <div className="mt-1 text-xs leading-relaxed text-neutral-400">
                    {s.body}
                  </div>
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-neutral-800 pt-4">
            <a
              href="https://console.cloud.google.com/iam-admin/serviceaccounts"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-[11px] font-medium text-neutral-200 ring-1 ring-neutral-700 transition hover:bg-neutral-700"
            >
              <ExternalLink className="h-3 w-3" />
              Google Cloud Console
            </a>
            <a
              href="https://developers.google.com/workspace/drive/api/guides/about-sdk"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-[11px] font-medium text-neutral-200 ring-1 ring-neutral-700 transition hover:bg-neutral-700"
            >
              <ExternalLink className="h-3 w-3" />
              Drive API docs
            </a>
          </div>

          <Checklist />
        </div>
      ) : null}
    </div>
  );
}

function Checklist() {
  const items = [
    "Service account created in Google Cloud Console",
    "credentials.json downloaded to project root",
    "Drive folder shared with the service-account email (Viewer)",
    "GOOGLE_DRIVE_FOLDER_ID set in .env",
    "Header badge reads LIVE · DRIVE after restart",
    "Ping Drive returns OK in the System & Cache panel",
  ];
  const [done, setDone] = useLocalStorage<boolean[]>(
    "aperture.checklist",
    items.map(() => false)
  );
  return (
    <div className="mt-5 rounded-xl border border-neutral-800 bg-neutral-950/40 p-4">
      <p className="mb-3 text-[11px] font-medium uppercase tracking-wide text-neutral-400">
        Live-mode checklist
      </p>
      <ul className="space-y-2">
        {items.map((label, i) => (
          <li key={i}>
            <button
              onClick={() =>
                setDone((d) => d.map((v, idx) => (idx === i ? !v : v)))
              }
              className="flex w-full items-start gap-2 text-left"
            >
              {done[i] ? (
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
              ) : (
                <Circle className="mt-0.5 h-4 w-4 shrink-0 text-neutral-600" />
              )}
              <span
                className={`text-xs ${
                  done[i]
                    ? "text-neutral-500 line-through"
                    : "text-neutral-300"
                }`}
              >
                {label}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
