"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Database,
  HardDrive,
  Trash2,
  RefreshCw,
  Activity,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Timer,
  RotateCcw,
} from "lucide-react";
import { useLocalStorage } from "@/hooks/use-local-storage";

interface CacheStats {
  size: number;
  max: number;
  ttlMs: number;
  calculatedSize: number;
  byteCacheSize?: number;
  byteCacheMaxBytes?: number;
  byteCacheBytes?: number;
}

interface HealthInfo {
  status: "ok" | "degraded" | "error";
  mode: "demo" | "google-drive";
  demoMode: boolean;
  folderId: string | null;
  credentialsPresent: boolean;
  credentialsPath: string;
  driveReady: boolean;
  driveInitError: string | null;
  cache: { size: number; max: number; ttlMs: number };
  drivePing: "skipped" | "ok" | "failed";
  checkedAt: string;
}

function fmtBytes(n: number): string {
  if (!n || n <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(n) / Math.log(1024));
  return `${(n / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function fmtTtl(ms: number): string {
  const min = ms / 60000;
  return `${min}m`;
}

interface ConfigInfo {
  cacheTtlMs: number;
  envTtlMs: number;
  runtimeOverrideMs: number | null;
  limits: { min: number; max: number };
}

export function CachePanel() {
  const [stats, setStats] = useState<CacheStats | null>(null);
  const [health, setHealth] = useState<HealthInfo | null>(null);
  const [config, setConfig] = useState<ConfigInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  // Draft TTL in MINUTES (local input state, applied on click).
  const [draftTtlMin, setDraftTtlMin] = useLocalStorage<number>(
    "aperture.draftTtlMin",
    10
  );

  const refresh = useCallback(async () => {
    try {
      const [sRes, hRes, cRes] = await Promise.all([
        fetch("/api/gallery/cache", { cache: "no-store" }),
        fetch("/api/gallery/health", { cache: "no-store" }),
        fetch("/api/gallery/config", { cache: "no-store" }),
      ]);
      const sj = await sRes.json();
      const hj = await hRes.json();
      const cj = await cRes.json();
      setStats(sj.stats);
      setHealth(hj);
      setConfig(cj);
      // Sync the draft input to the effective TTL on first load.
      setDraftTtlMin(Math.round((cj.cacheTtlMs ?? 600000) / 60000));
    } catch {
      /* noop */
    } finally {
      setLoading(false);
    }
  }, [setDraftTtlMin]);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 8000);
    return () => clearInterval(id);
  }, [refresh]);

  const evict = useCallback(
    async (scope?: "list" | "bytes") => {
      setBusy(true);
      try {
        const url = scope
          ? `/api/gallery/cache?scope=${scope}`
          : "/api/gallery/cache";
        const res = await fetch(url, { method: "POST" });
        const j = await res.json();
        const msg = scope
          ? scope === "list"
            ? `Cleared list cache (${j.evicted} entries)`
            : `Cleared byte cache (${j.detail?.bytes ?? j.evicted} entries)`
          : `Flushed all caches (list: ${j.detail?.list}, bytes: ${j.detail?.bytes})`;
        setToast(msg);
        setTimeout(() => setToast(null), 3500);
        await refresh();
      } finally {
        setBusy(false);
      }
    },
    [refresh]
  );

  const ping = useCallback(async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/gallery/health?ping=1", {
        cache: "no-store",
      });
      const j = await res.json();
      setHealth(j);
      setToast(
        j.drivePing === "ok"
          ? "Drive ping OK — folder reachable"
          : j.drivePing === "failed"
          ? `Drive ping FAILED — ${j.driveInitError ?? "unknown"}`
          : "Drive ping skipped (demo mode)"
      );
      setTimeout(() => setToast(null), 3500);
    } finally {
      setBusy(false);
    }
  }, []);

  const applyTtl = useCallback(
    async (minutes: number) => {
      setBusy(true);
      try {
        const ms = Math.round(minutes * 60000);
        const res = await fetch("/api/gallery/config", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ttlMs: ms }),
        });
        const j = await res.json();
        setConfig((prev) =>
          prev
            ? {
                ...prev,
                cacheTtlMs: j.cacheTtlMs,
                runtimeOverrideMs: j.runtimeOverrideMs,
              }
            : prev
        );
        const tag = j.runtimeOverrideMs ? " (override)" : " (env default)";
        setToast(`Cache TTL set to ${Math.round(j.cacheTtlMs / 60000)} min${tag}`);
        setTimeout(() => setToast(null), 3500);
        await refresh();
      } finally {
        setBusy(false);
      }
    },
    [refresh]
  );

  const resetTtl = useCallback(async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/gallery/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ttlMs: null }),
      });
      const j = await res.json();
      setConfig((prev) =>
        prev
          ? { ...prev, cacheTtlMs: j.cacheTtlMs, runtimeOverrideMs: null }
          : prev
      );
      setDraftTtlMin(Math.round(j.cacheTtlMs / 60000));
      setToast(
        `Cache TTL reset to env default (${Math.round(j.cacheTtlMs / 60000)} min)`
      );
      setTimeout(() => setToast(null), 3500);
      await refresh();
    } finally {
      setBusy(false);
    }
  }, [refresh, setDraftTtlMin]);

  const limitMin = Math.round((config?.limits.min ?? 10000) / 60000);
  const limitMax = Math.round((config?.limits.max ?? 86400000) / 60000);
  const overrideActive = !!config?.runtimeOverrideMs;

  const statusBadgeClass =
    health?.status === "ok"
      ? "bg-emerald-500/10 text-emerald-300 ring-emerald-400/30"
      : health?.status === "degraded"
      ? "bg-amber-500/10 text-amber-300 ring-amber-400/30"
      : "bg-rose-500/10 text-rose-300 ring-rose-400/30";

  return (
    <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-4 sm:p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/10 ring-1 ring-emerald-400/20">
            <Activity className="h-4 w-4 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">
              System & Cache
            </h3>
            <p className="text-[11px] text-neutral-500">
              Live backend diagnostics
            </p>
          </div>
        </div>
        <button
          onClick={refresh}
          disabled={loading}
          className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-2.5 py-1.5 text-[11px] font-medium text-neutral-300 ring-1 ring-neutral-700 transition hover:bg-neutral-700 disabled:opacity-50"
        >
          <RefreshCw
            className={`h-3 w-3 ${loading ? "animate-spin" : ""}`}
          />
          <span className="hidden sm:inline">Refresh</span>
        </button>
      </div>

      {/* Status row */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium ring-1 ${statusBadgeClass}`}
        >
          {health?.status === "ok" ? (
            <CheckCircle2 className="h-3 w-3" />
          ) : (
            <AlertTriangle className="h-3 w-3" />
          )}
          {health?.status?.toUpperCase() ?? "—"}
        </span>
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium ring-1 ${
            health?.demoMode
              ? "bg-amber-500/10 text-amber-300 ring-amber-400/30"
              : "bg-emerald-500/10 text-emerald-300 ring-emerald-400/30"
          }`}
        >
          {health?.demoMode ? "DEMO" : "LIVE · DRIVE"}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-neutral-800/60 px-2.5 py-1 text-[11px] text-neutral-300 ring-1 ring-neutral-700">
          {health?.credentialsPresent ? (
            <ShieldCheck className="h-3 w-3 text-emerald-400" />
          ) : (
            <XCircle className="h-3 w-3 text-neutral-500" />
          )}
          {health?.credentialsPresent ? "Creds present" : "No creds"}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-neutral-800/60 px-2.5 py-1 text-[11px] text-neutral-300 ring-1 ring-neutral-700">
          {health?.driveReady ? "Drive ready" : "Drive n/a"}
        </span>
      </div>

      {health?.driveInitError ? (
        <div className="mb-4 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-200">
          <p className="font-medium">Drive initialisation error</p>
          <p className="mt-1 break-words text-rose-200/80">
            {health.driveInitError}
          </p>
        </div>
      ) : null}

      {/* Stat tiles */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatTile
          icon={<Database className="h-3.5 w-3.5" />}
          label="List cache"
          value={`${stats?.size ?? 0}/${stats?.max ?? 0}`}
          sub={`TTL ${fmtTtl(stats?.ttlMs ?? 0)}`}
        />
        <StatTile
          icon={<HardDrive className="h-3.5 w-3.5" />}
          label="Byte cache"
          value={`${stats?.byteCacheSize ?? 0}`}
          sub={fmtBytes(stats?.byteCacheBytes ?? 0)}
        />
        <StatTile
          icon={<ShieldCheck className="h-3.5 w-3.5" />}
          label="Byte cap"
          value={fmtBytes(stats?.byteCacheMaxBytes ?? 0)}
          sub="LRU bounded"
        />
        <StatTile
          icon={<Activity className="h-3.5 w-3.5" />}
          label="Drive ping"
          value={
            health?.drivePing === "ok"
              ? "OK"
              : health?.drivePing === "failed"
              ? "FAIL"
              : "—"
          }
          sub={health?.checkedAt ? new Date(health.checkedAt).toLocaleTimeString() : ""}
        />
      </div>

      {/* TTL control */}
      <div className="mt-4 rounded-xl border border-neutral-800 bg-neutral-950/40 p-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-neutral-400">
            <Timer className="h-3.5 w-3.5 text-emerald-400/80" />
            <span className="text-[10px] uppercase tracking-wide">
              Cache TTL
            </span>
          </div>
          {overrideActive ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-sky-500/10 px-2 py-0.5 text-[10px] font-medium text-sky-300 ring-1 ring-sky-400/30">
              override active
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 rounded-full bg-neutral-800/60 px-2 py-0.5 text-[10px] text-neutral-400 ring-1 ring-neutral-700">
              env default
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative inline-flex items-center">
            <input
              type="number"
              min={limitMin}
              max={limitMax}
              value={draftTtlMin}
              onChange={(e) =>
                setDraftTtlMin(
                  Math.max(
                    limitMin,
                    Math.min(limitMax, Number(e.target.value) || limitMin)
                  )
                )
              }
              aria-label="Cache TTL in minutes"
              className="w-20 rounded-lg border border-neutral-700 bg-neutral-950/60 px-2 py-1.5 text-xs text-neutral-100 transition focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
            />
            <span className="pointer-events-none absolute right-2 text-[10px] text-neutral-500">
              min
            </span>
          </div>
          <button
            onClick={() => applyTtl(draftTtlMin)}
            disabled={busy}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500/15 px-3 py-1.5 text-[11px] font-medium text-emerald-200 ring-1 ring-emerald-400/30 transition hover:bg-emerald-500/25 disabled:opacity-50"
          >
            <Timer className="h-3 w-3" />
            Apply
          </button>
          <button
            onClick={resetTtl}
            disabled={busy || !overrideActive}
            className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-[11px] font-medium text-neutral-200 ring-1 ring-neutral-700 transition hover:bg-neutral-700 disabled:opacity-40"
            title="Revert to env default"
          >
            <RotateCcw className="h-3 w-3" />
            Reset
          </button>
          <span className="text-[10px] text-neutral-500">
            range {limitMin}–{limitMax} min
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-4 flex flex-wrap gap-2">
        <button
          onClick={() => evict("list")}
          disabled={busy}
          className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-[11px] font-medium text-neutral-200 ring-1 ring-neutral-700 transition hover:bg-neutral-700 disabled:opacity-50"
        >
          <Trash2 className="h-3 w-3" />
          Evict list
        </button>
        <button
          onClick={() => evict("bytes")}
          disabled={busy}
          className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-[11px] font-medium text-neutral-200 ring-1 ring-neutral-700 transition hover:bg-neutral-700 disabled:opacity-50"
        >
          <Trash2 className="h-3 w-3" />
          Evict bytes
        </button>
        <button
          onClick={() => evict(undefined)}
          disabled={busy}
          className="inline-flex items-center gap-1.5 rounded-lg bg-rose-500/15 px-3 py-1.5 text-[11px] font-medium text-rose-200 ring-1 ring-rose-400/30 transition hover:bg-rose-500/25 disabled:opacity-50"
        >
          <Trash2 className="h-3 w-3" />
          Flush all
        </button>
        <button
          onClick={ping}
          disabled={busy || health?.demoMode}
          className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500/15 px-3 py-1.5 text-[11px] font-medium text-emerald-200 ring-1 ring-emerald-400/30 transition hover:bg-emerald-500/25 disabled:opacity-40"
          title={health?.demoMode ? "Ping unavailable in demo mode" : "Verify Drive access"}
        >
          <Activity className="h-3 w-3" />
          Ping Drive
        </button>
      </div>

      {toast ? (
        <div className="mt-3 rounded-lg border border-neutral-700 bg-neutral-800/80 px-3 py-2 text-[11px] text-neutral-200">
          {toast}
        </div>
      ) : null}
    </div>
  );
}

function StatTile({
  icon,
  label,
  value,
  sub,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="rounded-xl border border-neutral-800 bg-neutral-950/50 p-3">
      <div className="flex items-center gap-1.5 text-neutral-400">
        <span className="text-emerald-400/80">{icon}</span>
        <span className="text-[10px] uppercase tracking-wide">{label}</span>
      </div>
      <div className="mt-1 text-base font-semibold text-white">{value}</div>
      {sub ? (
        <div className="text-[10px] text-neutral-500">{sub}</div>
      ) : null}
    </div>
  );
}
