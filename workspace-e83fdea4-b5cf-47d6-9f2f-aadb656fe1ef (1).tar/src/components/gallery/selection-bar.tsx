"use client";

import { CheckSquare, Download, Square, X, Package, HardDrive } from "lucide-react";

interface SelectionBarProps {
  selectedCount: number;
  totalCount: number;
  /** Total byte size of the currently-selected images (0 if none). */
  selectedSize: number;
  onSelectAll: () => void;
  onSelectNone: () => void;
  onClear: () => void;
  onDownload: () => void;
  onDownloadAll: () => void;
  downloading: boolean;
}

function fmtBytes(n: number): string {
  if (!n || n <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(n) / Math.log(1024));
  return `${(n / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

/**
 * SelectionBar — shown when multi-select mode is active. Displays the count
 * of selected images + their total size, a select-all toggle, a clear
 * button, a download button that triggers the zip endpoint, and a "Download
 * all" button that zips every image in the current view.
 */
export function SelectionBar({
  selectedCount,
  totalCount,
  selectedSize,
  onSelectAll,
  onSelectNone,
  onClear,
  onDownload,
  onDownloadAll,
  downloading,
}: SelectionBarProps) {
  const allSelected = selectedCount === totalCount && totalCount > 0;
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-400/30 bg-amber-400/5 px-3 py-2 sm:px-4">
      <div className="flex items-center gap-3">
        <button
          onClick={onSelectAll}
          className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] font-medium text-amber-200 transition hover:bg-amber-400/10"
          aria-label={allSelected ? "Deselect all" : "Select all"}
        >
          {allSelected ? (
            <CheckSquare className="h-3.5 w-3.5" />
          ) : (
            <Square className="h-3.5 w-3.5" />
          )}
          {allSelected ? "Deselect all" : "Select all"}
        </button>
        {selectedCount > 0 ? (
          <button
            onClick={onSelectNone}
            className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] font-medium text-amber-300/70 transition hover:bg-amber-400/10 hover:text-amber-200"
            aria-label="Select none"
            title="Clear selection (keep select mode)"
          >
            <Square className="h-3.5 w-3.5" />
            None
          </button>
        ) : null}
        <span className="text-[11px] font-medium text-amber-100">
          {selectedCount} selected
          <span className="text-amber-300/60"> / {totalCount}</span>
        </span>
        {selectedCount > 0 ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/10 px-2 py-0.5 text-[10px] font-medium text-amber-200 ring-1 ring-amber-400/20">
            <HardDrive className="h-3 w-3" />
            {fmtBytes(selectedSize)}
          </span>
        ) : null}
        <span className="hidden text-[10px] text-amber-300/50 sm:inline">
          shift-click for range
        </span>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={onDownloadAll}
          disabled={totalCount === 0 || downloading}
          className="inline-flex items-center gap-1.5 rounded-lg bg-sky-500/15 px-3 py-1.5 text-[11px] font-medium text-sky-200 ring-1 ring-sky-400/30 transition hover:bg-sky-500/25 disabled:opacity-40"
          title="Zip every image in the current view"
        >
          <Package className={`h-3.5 w-3.5 ${downloading ? "animate-bounce" : ""}`} />
          {downloading ? "Zipping…" : "Download all"}
        </button>
        <button
          onClick={onDownload}
          disabled={selectedCount === 0 || downloading}
          className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500/90 px-3 py-1.5 text-[11px] font-medium text-black transition hover:bg-emerald-400 disabled:opacity-40 disabled:hover:bg-emerald-500/90"
        >
          <Download className={`h-3.5 w-3.5 ${downloading ? "animate-bounce" : ""}`} />
          {downloading ? "Zipping…" : `Download ZIP`}
        </button>
        <button
          onClick={onClear}
          className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-2.5 py-1.5 text-[11px] font-medium text-neutral-300 ring-1 ring-neutral-700 transition hover:bg-neutral-700"
          aria-label="Exit select mode"
        >
          <X className="h-3.5 w-3.5" />
          Exit
        </button>
      </div>
    </div>
  );
}
