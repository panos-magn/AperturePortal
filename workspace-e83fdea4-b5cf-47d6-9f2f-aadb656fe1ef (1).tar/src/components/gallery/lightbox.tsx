"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  X,
  Download,
  Info,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  CaptionsOff,
  Captions,
  Play,
  Pause,
  Star,
} from "lucide-react";
import type { DriveFileDto } from "@/lib/gallery/types";

export type KenBurnsDirection = "in" | "out" | "random";

interface LightboxProps {
  items: DriveFileDto[];
  index: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
  onJump?: (i: number) => void;
  slideshowSpeed?: SlideshowSpeed;
  onSlideshowSpeedChange?: (ms: SlideshowSpeed) => void;
  isFavourite?: boolean;
  onToggleFavourite?: () => void;
  kenBurnsDirection?: KenBurnsDirection;
  onKenBurnsDirectionChange?: (d: KenBurnsDirection) => void;
}

function proxyUrl(id: string) {
  return `/api/gallery/images/${id}`;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

const MIN_ZOOM = 1;
const MAX_ZOOM = 4;
const SLIDESHOW_SPEEDS_MS = [2000, 4000, 8000] as const;
const DEFAULT_SPEED_MS = 4000;

export type SlideshowSpeed = (typeof SLIDESHOW_SPEEDS_MS)[number];

export function Lightbox({
  items,
  index,
  onClose,
  onPrev,
  onNext,
  onJump,
  slideshowSpeed = DEFAULT_SPEED_MS,
  onSlideshowSpeedChange,
  isFavourite = false,
  onToggleFavourite,
  kenBurnsDirection = "in",
  onKenBurnsDirectionChange,
}: LightboxProps) {
  const current = items[index];
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [showCaption, setShowCaption] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [slideshow, setSlideshow] = useState(false);
  const [slideProgress, setSlideProgress] = useState(0);
  const [meta, setMeta] = useState<{ width: number; height: number; type: string } | null>(null);
  const [videoDuration, setVideoDuration] = useState<number | null>(null);
  const [prevImage, setPrevImage] = useState<{ id: string; src: string } | null>(null);
  // Resolved direction per image — when `kenBurnsDirection === "random"`,
  // a new random "in"/"out" is picked on each index change for variety.
  const [resolvedDir, setResolvedDir] = useState<"in" | "out">("in");
  // Track the previously-displayed index so we can reset zoom/pan/loaded
  // synchronously when navigation happens (React 19 "adjust state during
  // render" pattern — avoids setState-in-effect cascades).
  const [prevIndex, setPrevIndex] = useState(index);
  if (index !== prevIndex) {
    // Capture the outgoing image for the crossfade layer.
    const outgoing = items[prevIndex];
    if (outgoing) {
      setPrevImage({ id: outgoing.id, src: proxyUrl(outgoing.id) });
    }
    setPrevIndex(index);
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setLoaded(false);
    setSlideProgress(0);
    setMeta(null);
    setVideoDuration(null);
    // Pick a fresh random direction when in "random" mode, for variety.
    setResolvedDir(kenBurnsDirection === "random" ? (Math.random() < 0.5 ? "in" : "out") : (kenBurnsDirection === "out" ? "out" : "in"));
  }
  // Clear the crossfade layer shortly after the new image has loaded.
  useEffect(() => {
    if (!prevImage) return;
    const id = setTimeout(() => setPrevImage(null), 600);
    return () => clearTimeout(id);
  }, [prevImage]);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<{
    dragging: boolean;
    startX: number;
    startY: number;
    baseX: number;
    baseY: number;
    pointerId?: number;
  }>({ dragging: false, startX: 0, startY: 0, baseX: 0, baseY: 0 });
  const touchRef = useRef<{
    startX: number;
    startY: number;
    active: boolean;
  }>({ startX: 0, startY: 0, active: false });

  const handleKey = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (zoom !== 1) {
          setZoom(1);
          setPan({ x: 0, y: 0 });
        } else if (document.fullscreenElement) {
          document.exitFullscreen?.();
        } else {
          onClose();
        }
      } else if (e.key === "ArrowLeft" || e.key.toLowerCase() === "k") onPrev();
      else if (e.key === "ArrowRight" || e.key.toLowerCase() === "j") onNext();
      else if (e.key === "Home") onJump?.(0);
      else if (e.key === "End") onJump?.(items.length - 1);
      else if (e.key === "+" || e.key === "=") setZoom((z) => Math.min(MAX_ZOOM, +(z + 0.5).toFixed(2)));
      else if (e.key === "-") setZoom((z) => Math.max(MIN_ZOOM, +(z - 0.5).toFixed(2)));
      else if (e.key === "0") {
        setZoom(1);
        setPan({ x: 0, y: 0 });
      } else if (e.key.toLowerCase() === "f") {
        if (!document.fullscreenElement) {
          containerRef.current?.requestFullscreen?.().catch(() => {});
        } else {
          document.exitFullscreen?.().catch(() => {});
        }
      } else if (e.key.toLowerCase() === "c") setShowCaption((s) => !s);
      else if (e.key.toLowerCase() === "b") onToggleFavourite?.();
      else if (e.key === " " || e.key.toLowerCase() === "s") {
        e.preventDefault();
        setSlideshow((s) => {
          if (s) setSlideProgress(0);
          return !s;
        });
      }
    },
    [onClose, onPrev, onNext, zoom, onJump, items.length, onToggleFavourite]
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKey);
      document.body.style.overflow = "";
    };
  }, [handleKey]);

  // Track fullscreen changes (so the button reflects reality even if the
  // user presses Esc to exit fullscreen).
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  // Slideshow auto-advance: a high-frequency ticker drives a progress bar,
  // and every `slideshowSpeed` ms we advance to the next image. Stops
  // automatically when only one image is present. (No synchronous setState
  // in the effect body — the reset happens inside the interval callback and
  // on cleanup via the slideshow toggle.) Changing the speed restarts the
  // timer cleanly via the dep array.
  useEffect(() => {
    if (!slideshow || items.length <= 1) return;
    const tickMs = 50;
    let elapsed = 0;
    const id = setInterval(() => {
      elapsed += tickMs;
      const pct = Math.min(1, elapsed / slideshowSpeed);
      setSlideProgress(pct);
      if (elapsed >= slideshowSpeed) {
        elapsed = 0;
        onNext();
      }
    }, tickMs);
    return () => clearInterval(id);
  }, [slideshow, items.length, onNext, slideshowSpeed]);

  // Fetch image metadata (dimensions) when the displayed image changes.
  // Uses the /meta endpoint which probes via sharp + caches server-side.
  useEffect(() => {
    let cancelled = false;
    const id = current?.id;
    if (!id) return;
    fetch(`/api/gallery/images/${id}/meta`)
      .then((r) => (r.ok ? r.json() : null))
      .then((m) => {
        if (!cancelled && m) setMeta(m);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [current?.id]);

  // Fullscreen toggle — called from the toolbar button. The keyboard "f"
  // shortcut inlines the same logic to keep handleKey self-contained.
  const toggleFullscreen = () => {
    if (typeof document === "undefined") return;
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const toggleSlideshow = () => {
    setSlideshow((s) => {
      if (s) setSlideProgress(0); // reset bar when pausing
      return !s;
    });
  };

  const zoomIn = () => setZoom((z) => Math.min(MAX_ZOOM, +(z + 0.5).toFixed(2)));
  const zoomOut = () => {
    setZoom((z) => {
      const nz = Math.max(MIN_ZOOM, +(z - 0.5).toFixed(2));
      if (nz === 1) setPan({ x: 0, y: 0 });
      return nz;
    });
  };
  const resetZoom = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // ---- Mouse drag-to-pan (only when zoomed) ----
  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (zoom === 1) return;
    dragRef.current = {
      dragging: true,
      startX: e.clientX,
      startY: e.clientY,
      baseX: pan.x,
      baseY: pan.y,
      pointerId: e.pointerId,
    };
    (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.dragging) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    setPan({ x: dragRef.current.baseX + dx, y: dragRef.current.baseY + dy });
  };
  const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragRef.current.dragging) {
      dragRef.current.dragging = false;
      (e.currentTarget as HTMLDivElement).releasePointerCapture?.(e.pointerId);
    }
  };

  // ---- Touch swipe (only when NOT zoomed) ----
  const onTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (zoom !== 1) return;
    const t = e.touches[0];
    touchRef.current = { startX: t.clientX, startY: t.clientY, active: true };
  };
  const onTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchRef.current.active) return;
    touchRef.current.active = false;
    const t = e.changedTouches[0];
    const dx = t.clientX - touchRef.current.startX;
    const dy = t.clientY - touchRef.current.startY;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
      if (dx < 0) onNext();
      else onPrev();
    } else if (dy < -80 && Math.abs(dy) > Math.abs(dx)) {
      onClose(); // swipe up to close
    }
  };

  // Double-click / double-tap to zoom
  const onDoubleClick = () => {
    if (zoom === 1) setZoom(2);
    else resetZoom();
  };

  if (!current) return null;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-sm animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-label="Image viewer"
      onClick={(e) => {
        // Click on the backdrop (not on image/controls) closes — only when not zoomed.
        if (e.target === e.currentTarget && zoom === 1) onClose();
      }}
    >
      {/* Top bar */}
      <div className="flex items-center justify-between gap-2 px-3 py-3 text-neutral-300 sm:px-6">
        <div className="flex min-w-0 items-center gap-2 text-sm">
          <Info className="h-4 w-4 shrink-0 text-emerald-400" />
          <span className="truncate font-mono text-xs text-neutral-400">
            {current.id}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <ToolButton onClick={zoomOut} disabled={zoom <= MIN_ZOOM} label="Zoom out (-)">
            <ZoomOut className="h-4 w-4" />
          </ToolButton>
          <span className="min-w-[3.5rem] rounded-md bg-white/5 px-2 py-1 text-center font-mono text-[11px] text-neutral-300 ring-1 ring-white/10">
            {Math.round(zoom * 100)}%
          </span>
          <ToolButton onClick={zoomIn} disabled={zoom >= MAX_ZOOM} label="Zoom in (+)">
            <ZoomIn className="h-4 w-4" />
          </ToolButton>
          <ToolButton onClick={resetZoom} disabled={zoom === 1} label="Reset zoom (0)">
            <Maximize2 className="h-4 w-4" />
          </ToolButton>
          <span className="mx-1 hidden h-5 w-px bg-white/10 sm:block" />
          <ToolButton onClick={() => setShowCaption((s) => !s)} label="Toggle caption (C)">
            {showCaption ? <CaptionsOff className="h-4 w-4" /> : <Captions className="h-4 w-4" />}
          </ToolButton>
          <ToolButton
            onClick={toggleSlideshow}
            label="Slideshow (Space)"
            disabled={items.length <= 1}
          >
            {slideshow ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </ToolButton>
          {slideshow ? (
            <SlideshowSpeedSelector
              value={slideshowSpeed}
              onChange={(v) => onSlideshowSpeedChange?.(v)}
            />
          ) : null}
          {slideshow && onKenBurnsDirectionChange ? (
            <button
              onClick={() => {
                const next =
                  kenBurnsDirection === "in"
                    ? "out"
                    : kenBurnsDirection === "out"
                    ? "random"
                    : "in";
                onKenBurnsDirectionChange(next);
              }}
              title={`Ken Burns: zoom ${kenBurnsDirection} (click to cycle in → out → random)`}
              aria-label={`Ken Burns zoom ${kenBurnsDirection} — click to cycle`}
              className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-1 text-[10px] font-medium text-neutral-300 ring-1 ring-white/10 transition hover:bg-white/10 hover:text-white"
            >
              <ZoomIn className="h-3 w-3" />
              {kenBurnsDirection}
            </button>
          ) : null}
          <ToolButton onClick={toggleFullscreen} label="Fullscreen (F)">
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </ToolButton>
          <span className="mx-1 hidden h-5 w-px bg-white/10 sm:block" />
          <button
            onClick={onClose}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-neutral-200 ring-1 ring-white/10 transition hover:bg-white/10 hover:text-white focus:outline-none focus:ring-2 focus:ring-emerald-400/60"
            aria-label="Close (Esc)"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Slideshow progress bar */}
      {slideshow ? (
        <div className="h-0.5 w-full bg-white/5">
          <div
            className="h-full bg-emerald-400 transition-[width] duration-75 ease-linear"
            style={{ width: `${slideProgress * 100}%` }}
          />
        </div>
      ) : null}

      {/* Image stage */}
      <div
        className="relative flex flex-1 items-center justify-center overflow-hidden px-3 pb-3 sm:px-16"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        <button
          onClick={onPrev}
          disabled={items.length <= 1}
          className="absolute left-1 z-10 inline-flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white ring-1 ring-white/20 backdrop-blur-sm transition hover:bg-white/20 disabled:opacity-30 focus:outline-none focus:ring-2 focus:ring-emerald-400/60 sm:left-4"
          aria-label="Previous image"
        >
          <ChevronLeft className="h-6 w-6" />
        </button>

        <div
          className={`relative flex max-h-full max-w-full items-center justify-center ${
            zoom > 1 ? "cursor-grab active:cursor-grabbing" : ""
          }`}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          onDoubleClick={onDoubleClick}
        >
          {!loaded ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-10 w-10 animate-spin rounded-full border-2 border-emerald-400/30 border-t-emerald-400" />
            </div>
          ) : null}
          {/* Crossfade layer: the outgoing image sits behind the current one
              and fades out once the new image has loaded. Gives a smooth
              dissolve during slideshow + manual navigation. */}
          {prevImage ? (
            <img
              src={prevImage.src}
              alt=""
              aria-hidden
              draggable={false}
              className="pointer-events-none absolute inset-0 m-auto max-h-[78vh] max-w-[92vw] rounded-lg object-contain shadow-2xl ring-1 ring-white/10 transition-opacity duration-500 ease-out"
              style={{ opacity: loaded ? 0 : 1 }}
            />
          ) : null}
          {current.kind === "video" ? (
            <video
              key={current.id}
              src={proxyUrl(current.id)}
              poster={current.thumbnailLink}
              controls
              playsInline
              autoPlay
              className="relative max-h-[78vh] max-w-[92vw] rounded-lg shadow-2xl ring-1 ring-white/10"
              style={{ opacity: loaded ? 1 : 0 }}
              onLoadedData={() => setLoaded(true)}
              onLoadedMetadata={(e) => {
                const v = e.currentTarget;
                if (v.duration && isFinite(v.duration)) {
                  setVideoDuration(v.duration);
                  setMeta({
                    width: v.videoWidth,
                    height: v.videoHeight,
                    type: current.mimeType.split("/")[1] || "video",
                  });
                }
              }}
            />
          ) : (
            <img
              key={current.id}
              src={proxyUrl(current.id)}
              alt={current.name}
              draggable={false}
              onLoad={() => setLoaded(true)}
              className={`relative max-h-[78vh] max-w-[92vw] rounded-lg object-contain shadow-2xl ring-1 ring-white/10 transition-[opacity,transform] duration-300 ease-out ${
                slideshow && loaded && zoom === 1
                  ? resolvedDir === "out"
                    ? "kenburns-out"
                    : "kenburns-in"
                  : ""
              }`}
              style={{
                // Base transform (zoom/pan). Ken Burns composes on top via the
                // --kb-base CSS var so it doesn't fight the inline transform.
                ["--kb-base" as string]: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                ["--kb-duration" as string]: `${slideshowSpeed}ms`,
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                opacity: loaded ? 1 : 0,
              }}
            />
          )}
        </div>

        <button
          onClick={onNext}
          disabled={items.length <= 1}
          className="absolute right-1 z-10 inline-flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-white ring-1 ring-white/20 backdrop-blur-sm transition hover:bg-white/20 disabled:opacity-30 focus:outline-none focus:ring-2 focus:ring-emerald-400/60 sm:right-4"
          aria-label="Next image"
        >
          <ChevronRight className="h-6 w-6" />
        </button>
      </div>

      {/* Caption bar */}
      {showCaption ? (
        <div className="flex flex-col gap-2 border-t border-white/10 bg-black/50 px-4 py-3 text-neutral-200 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div className="min-w-0 flex-1">
            <p className="line-clamp-2 text-sm font-medium text-white sm:line-clamp-1">
              {current.name}
            </p>
            <p className="text-xs text-neutral-400">
              Captured {formatDate(current.createdTime)}
              {current.size ? ` · ${formatBytes(Number(current.size))}` : ""}
              {videoDuration != null
                ? ` · ${formatDuration(videoDuration)}`
                : ""}
              {meta && meta.width > 0
                ? ` · ${meta.width}×${meta.height}${meta.type ? ` ${meta.type}` : ""}`
                : current.mimeType
                ? ` · ${current.mimeType}`
                : ""}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="rounded-full bg-white/5 px-3 py-1 text-xs font-mono text-neutral-300 ring-1 ring-white/10">
              {index + 1} / {items.length}
            </span>
            {onToggleFavourite ? (
              <button
                onClick={onToggleFavourite}
                aria-pressed={isFavourite}
                aria-label={isFavourite ? "Remove from favourites (B)" : "Add to favourites (B)"}
                title={isFavourite ? "Remove from favourites (B)" : "Add to favourites (B)"}
                className={`inline-flex h-8 w-8 items-center justify-center rounded-full ring-1 transition focus:outline-none focus:ring-2 focus:ring-amber-400/60 ${
                  isFavourite
                    ? "bg-amber-400/15 text-amber-300 ring-amber-400/40 hover:bg-amber-400/25"
                    : "bg-white/5 text-neutral-300 ring-white/10 hover:bg-white/10 hover:text-amber-200"
                }`}
              >
                <Star className={`h-4 w-4 ${isFavourite ? "fill-amber-300" : ""}`} />
              </button>
            ) : null}
            <a
              href={proxyUrl(current.id)}
              download={current.name}
              className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/90 px-3 py-1.5 text-xs font-medium text-black transition hover:bg-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-400/60"
            >
              <Download className="h-3.5 w-3.5" />
              Download
            </a>
          </div>
        </div>
      ) : (
        <div className="h-2" />
      )}

      {/* Thumbnail filmstrip */}
      {items.length > 1 ? (
        <Filmstrip
          items={items}
          current={index}
          onJump={(i) => onJump?.(i)}
        />
      ) : null}

      {/* Keyboard hint — only when no filmstrip (single image) to avoid
          overlapping the thumbnail rail. */}
      {items.length <= 1 ? (
        <div className="pointer-events-none absolute bottom-3 left-1/2 hidden -translate-x-1/2 items-center gap-2 rounded-full bg-black/60 px-3 py-1 text-[10px] text-neutral-400 ring-1 ring-white/10 lg:flex">
          <Kbd>+</Kbd>/<Kbd>−</Kbd> zoom · <Kbd>F</Kbd> fullscreen · <Kbd>C</Kbd> caption · <Kbd>Esc</Kbd> close
        </div>
      ) : null}
    </div>
  );
}

/**
 * Filmstrip — horizontally-scrollable thumbnail rail at the bottom of the
 * lightbox. The current image is highlighted; clicking any thumb jumps to it.
 * Auto-scrolls the active thumb into view on navigation.
 */
function Filmstrip({
  items,
  current,
  onJump,
}: {
  items: DriveFileDto[];
  current: number;
  onJump: (i: number) => void;
}) {
  const railRef = useRef<HTMLDivElement | null>(null);
  const activeRef = useRef<HTMLButtonElement | null>(null);

  // Scroll the active thumbnail into the centre of the rail on change.
  useEffect(() => {
    const rail = railRef.current;
    const active = activeRef.current;
    if (!rail || !active) return;
    const railRect = rail.getBoundingClientRect();
    const activeRect = active.getBoundingClientRect();
    const offset =
      activeRect.left -
      railRect.left -
      (railRect.width / 2 - activeRect.width / 2);
    rail.scrollBy({ left: offset, behavior: "smooth" });
  }, [current]);

  return (
    <div className="border-t border-white/10 bg-black/40">
      <div
        ref={railRef}
        className="scroll-area-thin flex gap-2 overflow-x-auto px-4 py-2 sm:px-6"
      >
        {items.map((item, i) => {
          const active = i === current;
          return (
            <button
              key={item.id}
              ref={active ? activeRef : undefined}
              onClick={() => onJump(i)}
              aria-label={`Jump to image ${i + 1}: ${item.name}`}
              aria-current={active ? "true" : undefined}
              className={`relative h-12 w-16 shrink-0 overflow-hidden rounded-md ring-1 transition sm:h-14 sm:w-20 ${
                active
                  ? "ring-2 ring-emerald-400"
                  : "ring-white/10 opacity-60 hover:opacity-100"
              }`}
            >
              <img
                src={proxyUrl(item.id)}
                alt=""
                loading="lazy"
                className="h-full w-full object-cover"
              />
              {active ? (
                <span className="absolute inset-x-0 bottom-0 bg-emerald-400/90 py-0.5 text-center font-mono text-[9px] text-black">
                  {i + 1}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ToolButton({
  children,
  onClick,
  disabled,
  label,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      title={label}
      className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-neutral-200 ring-1 ring-white/10 transition hover:bg-white/10 hover:text-white disabled:opacity-30 focus:outline-none focus:ring-2 focus:ring-emerald-400/60"
    >
      {children}
    </button>
  );
}

function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[10px] text-neutral-200 ring-1 ring-white/10">
      {children}
    </kbd>
  );
}

/**
 * SlideshowSpeedSelector — a compact segmented control (2s / 4s / 8s) shown
 * inline in the lightbox toolbar while the slideshow is running.
 */
function SlideshowSpeedSelector({
  value,
  onChange,
}: {
  value: SlideshowSpeed;
  onChange: (ms: SlideshowSpeed) => void;
}) {
  return (
    <div
      className="inline-flex items-center rounded-full bg-white/5 p-0.5 ring-1 ring-white/10"
      role="group"
      aria-label="Slideshow speed"
    >
      {SLIDESHOW_SPEEDS_MS.map((ms) => {
        const active = ms === value;
        return (
          <button
            key={ms}
            onClick={() => onChange(ms)}
            aria-pressed={active}
            title={`${ms / 1000}s per image`}
            className={`rounded-full px-2 py-1 text-[10px] font-medium transition ${
              active
                ? "bg-emerald-500/90 text-black"
                : "text-neutral-300 hover:text-white"
            }`}
          >
            {ms / 1000}s
          </button>
        );
      })}
    </div>
  );
}

function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return "—";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

/** Format a video duration in seconds as M:SS or H:MM:SS. */
function formatDuration(seconds: number): string {
  if (!isFinite(seconds) || seconds <= 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${m}:${String(s).padStart(2, "0")}`;
}
