"use client";

import { useEffect, useState } from "react";
import { History, X } from "lucide-react";
import type { DriveFileDto } from "@/lib/gallery/types";
import { cn } from "@/lib/utils";

export interface RecentEntry {
  id: string;
  ts: number; // epoch ms when viewed
}

interface RecentlyViewedProps {
  /** All gallery items (to resolve ids → metadata). */
  items: DriveFileDto[];
  /** Ordered list of recently-viewed entries (newest first). */
  recentEntries: RecentEntry[];
  onOpen: (item: DriveFileDto) => void;
  onClear: () => void;
}

function proxyUrl(id: string) {
  return `/api/gallery/images/${id}`;
}

/** Format a relative-time string like "2m ago", "just now", "3h ago". */
function timeAgo(ts: number, now: number): string {
  const diff = Math.max(0, now - ts);
  const s = Math.floor(diff / 1000);
  if (s < 10) return "just now";
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

/** Group label for a timestamp: "Today", "Yesterday", or a date string. */
function dayLabel(ts: number, now: number): string {
  const d = new Date(ts);
  const today = new Date(now);
  const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
  if (ts >= startOfToday) return "Today";
  if (ts >= startOfYesterday) return "Yesterday";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

/**
 * Recently-viewed rail — a horizontal strip of thumbnails for images the
 * client has opened in the lightbox. Rendered above the main gallery when
 * there is at least one recent entry. Order is newest-first.
 *
 * Re-ticks every 30s so the relative timestamps ("2m ago") stay fresh.
 */
export function RecentlyViewed({
  items,
  recentEntries,
  onOpen,
  onClear,
}: RecentlyViewedProps) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(id);
  }, []);

  const byId = new Map(items.map((it) => [it.id, it]));
  const recent = recentEntries
    .map((e) => ({ item: byId.get(e.id), ts: e.ts }))
    .filter((x): x is { item: DriveFileDto; ts: number } => !!x.item)
    .slice(0, 12);

  if (recent.length === 0) return null;

  return (
    <div className="mb-6 rounded-2xl border border-neutral-800 bg-neutral-900/40 p-3 sm:p-4">
      <div className="mb-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-500/10 ring-1 ring-violet-400/20">
            <History className="h-3.5 w-3.5 text-violet-400" />
          </div>
          <div>
            <h3 className="text-xs font-semibold text-white">
              Recently viewed
            </h3>
            <p className="text-[10px] text-neutral-500">
              {recent.length} image{recent.length === 1 ? "" : "s"} · stored locally
            </p>
          </div>
        </div>
        <button
          onClick={onClear}
          className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] text-neutral-400 transition hover:bg-neutral-800 hover:text-neutral-200"
          aria-label="Clear recently viewed"
        >
          <X className="h-3 w-3" />
          Clear
        </button>
      </div>
      <div className="scroll-area-thin flex items-center gap-2 overflow-x-auto pb-1">
        {recent.map(({ item, ts }, i) => {
          const label = dayLabel(ts, now);
          const prevLabel = i > 0 ? dayLabel(recent[i - 1].ts, now) : null;
          const showDivider = label !== prevLabel;
          // Count how many entries fall in this same day group (for the
          // divider badge: "Today (3)").
          const groupCount = showDivider
            ? recent.filter(
                (r) => dayLabel(r.ts, now) === label
              ).length
            : 0;
          return (
            <div key={item.id} className="flex shrink-0 items-center gap-2">
              {showDivider ? (
                <span className="flex shrink-0 items-center gap-1 rounded-md bg-violet-500/10 px-2 py-1 text-[9px] font-semibold uppercase tracking-wide text-violet-300 ring-1 ring-violet-400/20">
                  {label}
                  <span className="rounded bg-violet-400/20 px-1 text-[8px] text-violet-200">
                    {groupCount}
                  </span>
                </span>
              ) : null}
              <button
                onClick={() => onOpen(item)}
                className={cn(
                  "group relative h-14 w-20 shrink-0 overflow-hidden rounded-lg ring-1 ring-neutral-700 transition",
                  "hover:ring-2 hover:ring-violet-400/70 focus:outline-none focus:ring-2 focus:ring-violet-400/70 sm:h-16 sm:w-24"
                )}
                title={`${item.name} · viewed ${timeAgo(ts, now)}`}
                aria-label={`Open ${item.name} again — viewed ${timeAgo(ts, now)}`}
              >
                <img
                  src={proxyUrl(item.id)}
                  alt={item.name}
                  loading="lazy"
                  className="h-full w-full object-cover transition group-hover:scale-105"
                />
                <span className="absolute inset-x-0 bottom-0 truncate bg-gradient-to-t from-black/90 to-transparent px-1.5 py-1 pt-3 text-left text-[9px] font-medium text-neutral-200">
                  {item.name}
                </span>
                <span className="absolute right-1 top-1 rounded bg-black/60 px-1 py-0.5 font-mono text-[8px] text-violet-300 ring-1 ring-violet-400/20 backdrop-blur-sm">
                  {timeAgo(ts, now)}
                </span>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
