"use client";

import { useEffect, useRef, useState } from "react";
import { ImageIcon } from "lucide-react";

interface DimensionBadgeProps {
  fileId: string;
  /** When "video", skip the sharp-based /meta probe (sharp can't parse video)
   *  and instead show a duration badge once the video element loads metadata. */
  kind?: "image" | "video";
}

interface Meta {
  width: number;
  height: number;
  type: string;
}

/**
 * DimensionBadge — lazily fetches image dimensions from the `/meta`
 * endpoint on first render and displays a compact "1920×1080" badge.
 *
 * For videos, sharp can't probe dimensions, so the badge is hidden on cards
 * (the lightbox caption handles video metadata client-side instead).
 *
 * Module-level cache so multiple badges for the same fileId share a single
 * fetch. Errors are swallowed (badge stays hidden).
 */
const metaCache = new Map<string, Meta | null>();

export function DimensionBadge({ fileId, kind = "image" }: DimensionBadgeProps) {
  // Lazy init from the module cache so already-fetched meta shows instantly
  // without a setState-in-effect.
  const [meta, setMeta] = useState<Meta | null>(() =>
    metaCache.get(fileId) ?? null
  );
  const fetchedRef = useRef(false);

  useEffect(() => {
    if (fetchedRef.current) return;
    fetchedRef.current = true;
    // If already cached (and non-null), the lazy init already covered it.
    if (metaCache.has(fileId)) return;
    fetch(`/api/gallery/images/${fileId}/meta`)
      .then((r) => (r.ok ? r.json() : null))
      .then((m: Meta | null) => {
        metaCache.set(fileId, m);
        setMeta(m);
      })
      .catch(() => {
        metaCache.set(fileId, null);
      });
  }, [fileId]);

  // Videos skip the sharp-based badge (sharp can't parse video).
  if (kind === "video") return null;
  if (!meta || meta.width === 0) return null;

  return (
    <span className="inline-flex items-center gap-1 rounded-md bg-black/65 px-1.5 py-0.5 font-mono text-[9px] text-neutral-200 ring-1 ring-white/10 backdrop-blur-sm">
      <ImageIcon className="h-2.5 w-2.5 text-emerald-400/80" />
      {meta.width}×{meta.height}
    </span>
  );
}
