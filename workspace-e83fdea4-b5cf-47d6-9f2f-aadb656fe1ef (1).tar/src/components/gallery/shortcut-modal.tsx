"use client";

import { useEffect } from "react";
import { X } from "lucide-react";

interface ShortcutGroup {
  title: string;
  items: { keys: string[]; desc: string }[];
}

const GROUPS: ShortcutGroup[] = [
  {
    title: "Gallery",
    items: [
      { keys: ["/"], desc: "Focus the search input" },
      { keys: ["G"], desc: "Grid layout" },
      { keys: ["M"], desc: "Masonry layout" },
      { keys: ["X"], desc: "Exit select mode" },
      { keys: ["Ctrl", "Shift", "A"], desc: "Clear selection" },
      { keys: ["?"], desc: "Open this cheat sheet" },
    ],
  },
  {
    title: "Lightbox navigation",
    items: [
      { keys: ["←"], desc: "Previous image" },
      { keys: ["→"], desc: "Next image" },
      { keys: ["K"], desc: "Previous image (Vim-style)" },
      { keys: ["J"], desc: "Next image (Vim-style)" },
      { keys: ["Home"], desc: "Jump to first image" },
      { keys: ["End"], desc: "Jump to last image" },
      { keys: ["Esc"], desc: "Close lightbox" },
    ],
  },
  {
    title: "Lightbox view",
    items: [
      { keys: ["+"], desc: "Zoom in" },
      { keys: ["−"], desc: "Zoom out" },
      { keys: ["0"], desc: "Reset zoom" },
      { keys: ["F"], desc: "Toggle fullscreen" },
      { keys: ["C"], desc: "Toggle caption bar" },
      { keys: ["B"], desc: "Toggle favourite (bookmark)" },
      { keys: ["Space"], desc: "Play / pause slideshow" },
      { keys: ["S"], desc: "Play / pause slideshow" },
    ],
  },
];

export function ShortcutModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      aria-label="Keyboard shortcuts"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900 shadow-2xl">
        <div className="flex items-center justify-between border-b border-neutral-800 px-5 py-3">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Keyboard shortcuts
            </h3>
            <p className="text-[11px] text-neutral-500">
              Press <Kbd>?</Kbd> anywhere to toggle this reference
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-neutral-300 ring-1 ring-white/10 transition hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="scroll-area-thin max-h-[70vh] overflow-y-auto px-5 py-4">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            {GROUPS.map((g) => (
              <div key={g.title}>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                  {g.title}
                </p>
                <ul className="space-y-1.5">
                  {g.items.map((it) => (
                    <li
                      key={it.desc}
                      className="flex items-center justify-between gap-2"
                    >
                      <span className="text-xs text-neutral-300">{it.desc}</span>
                      <span className="flex shrink-0 items-center gap-1">
                        {it.keys.map((k) => (
                          <Kbd key={k}>{k}</Kbd>
                        ))}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="rounded border border-neutral-700 bg-neutral-800 px-1.5 py-0.5 font-mono text-[10px] text-neutral-200">
      {children}
    </kbd>
  );
}
