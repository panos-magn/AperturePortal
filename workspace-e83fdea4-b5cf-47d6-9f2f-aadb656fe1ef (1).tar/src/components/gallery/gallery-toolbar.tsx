"use client";

import { Search, X, ArrowDownUp, Calendar, Type, HardDrive, Star, CheckSquare } from "lucide-react";
import { LayoutToggle } from "./gallery-grid";
import { cn } from "@/lib/utils";

export type SortKey = "date-desc" | "date-asc" | "name-asc" | "name-desc" | "size-desc" | "size-asc";

interface GalleryToolbarProps {
  query: string;
  onQueryChange: (q: string) => void;
  sort: SortKey;
  onSortChange: (s: SortKey) => void;
  layout: "grid" | "masonry";
  onLayoutChange: (l: "grid" | "masonry") => void;
  totalCount: number;
  shownCount: number;
  /** Number of favourites currently in the collection. */
  favouritesCount: number;
  /** Whether the favourites-only filter is active. */
  showFavouritesOnly: boolean;
  onToggleFavouritesFilter: () => void;
  /** Multi-select mode. */
  selectMode: boolean;
  onToggleSelectMode: () => void;
}

const SORT_OPTIONS: { value: SortKey; label: string; icon: React.ReactNode }[] = [
  { value: "date-desc", label: "Newest", icon: <Calendar className="h-3 w-3" /> },
  { value: "date-asc", label: "Oldest", icon: <Calendar className="h-3 w-3" /> },
  { value: "name-asc", label: "Name A→Z", icon: <Type className="h-3 w-3" /> },
  { value: "name-desc", label: "Name Z→A", icon: <Type className="h-3 w-3" /> },
  { value: "size-desc", label: "Largest", icon: <HardDrive className="h-3 w-3" /> },
  { value: "size-asc", label: "Smallest", icon: <HardDrive className="h-3 w-3" /> },
];

export function GalleryToolbar({
  query,
  onQueryChange,
  sort,
  onSortChange,
  layout,
  onLayoutChange,
  totalCount,
  shownCount,
  favouritesCount,
  showFavouritesOnly,
  onToggleFavouritesFilter,
  selectMode,
  onToggleSelectMode,
}: GalleryToolbarProps) {
  const filtering = query.trim().length > 0;
  return (
    <div className="mb-5 flex flex-col gap-3 rounded-2xl border border-neutral-800 bg-neutral-900/40 p-3 sm:flex-row sm:items-center sm:justify-between sm:p-4">
      {/* Left: search */}
      <div className="flex flex-1 items-center gap-3">
        <div className="relative w-full max-w-xs">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-neutral-500" />
          <input
            type="search"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Search images…"
            aria-label="Search images by name (press / to focus)"
            className="w-full rounded-lg border border-neutral-700 bg-neutral-950/60 py-1.5 pl-9 pr-9 text-xs text-neutral-100 placeholder:text-neutral-500 transition focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
          />
          {filtering ? (
            <button
              onClick={() => onQueryChange("")}
              aria-label="Clear search"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-neutral-500 transition hover:text-neutral-200"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          ) : (
            <kbd
              className="pointer-events-none absolute right-2 top-1/2 hidden -translate-y-1/2 items-center rounded border border-neutral-700 bg-neutral-800/80 px-1.5 py-0.5 font-mono text-[9px] text-neutral-400 sm:inline-flex"
              aria-hidden
            >
              /
            </kbd>
          )}
        </div>
        <span
          className={cn(
            "hidden shrink-0 text-xs sm:inline",
            filtering ? "text-emerald-300" : "text-neutral-500"
          )}
        >
          {filtering
            ? `${shownCount}/${totalCount}`
            : `${totalCount} image${totalCount === 1 ? "" : "s"}`}
        </span>
      </div>

      {/* Right: select + favourites filter + sort + layout */}
      <div className="flex items-center gap-2">
        <button
          onClick={onToggleSelectMode}
          aria-pressed={selectMode}
          title="Multi-select mode"
          className={cn(
            "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-medium ring-1 transition",
            selectMode
              ? "bg-emerald-400/15 text-emerald-300 ring-emerald-400/40"
              : "bg-neutral-950/60 text-neutral-400 ring-neutral-700 hover:text-neutral-200"
          )}
        >
          <CheckSquare className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Select</span>
        </button>
        <button
          onClick={onToggleFavouritesFilter}
          aria-pressed={showFavouritesOnly}
          title="Show favourites only"
          className={cn(
            "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-medium ring-1 transition",
            showFavouritesOnly
              ? "bg-amber-400/15 text-amber-300 ring-amber-400/40"
              : "bg-neutral-950/60 text-neutral-400 ring-neutral-700 hover:text-neutral-200"
          )}
        >
          <Star className={cn("h-3.5 w-3.5", showFavouritesOnly && "fill-amber-300")} />
          <span className="hidden sm:inline">Favourites</span>
          {favouritesCount > 0 ? (
            <span
              className={cn(
                "rounded-full px-1.5 py-0.5 text-[9px] font-semibold",
                showFavouritesOnly
                  ? "bg-amber-400/20 text-amber-200"
                  : "bg-neutral-800 text-neutral-400"
              )}
            >
              {favouritesCount}
            </span>
          ) : null}
        </button>
        <div className="relative inline-flex items-center">
          <ArrowDownUp className="pointer-events-none absolute left-2.5 top-1/2 h-3 w-3 -translate-y-1/2 text-neutral-500" />
          <select
            value={sort}
            onChange={(e) => onSortChange(e.target.value as SortKey)}
            aria-label="Sort images"
            className="appearance-none rounded-lg border border-neutral-700 bg-neutral-950/60 py-1.5 pl-8 pr-7 text-xs font-medium text-neutral-100 transition focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value} className="bg-neutral-900">
                {o.label}
              </option>
            ))}
          </select>
          <svg
            className="pointer-events-none absolute right-2 top-1/2 h-3 w-3 -translate-y-1/2 text-neutral-500"
            viewBox="0 0 12 12"
            fill="none"
            aria-hidden
          >
            <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <LayoutToggle layout={layout} onChange={onLayoutChange} />
      </div>
    </div>
  );
}
