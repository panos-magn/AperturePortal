"use client";

import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarButtonProps {
  active: boolean;
  onToggle: () => void;
  size?: "sm" | "md";
  className?: string;
  label?: string;
}

/**
 * StarButton — a favourites toggle used on gallery cards and in the lightbox.
 * Filled amber when active, outlined neutral when inactive. Stops propagation
 * so it can sit inside a clickable card without triggering the card's open.
 */
export function StarButton({
  active,
  onToggle,
  size = "md",
  className,
  label = "Toggle favourite",
}: StarButtonProps) {
  const dim = size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4";
  const box = size === "sm" ? "h-7 w-7" : "h-9 w-9";
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        e.preventDefault();
        onToggle();
      }}
      aria-label={label}
      aria-pressed={active}
      title={label}
      className={cn(
        "inline-flex items-center justify-center rounded-full backdrop-blur-sm transition",
        "focus:outline-none focus:ring-2 focus:ring-amber-400/60",
        active
          ? "bg-amber-400/15 text-amber-300 ring-1 ring-amber-400/40 hover:bg-amber-400/25"
          : "bg-black/50 text-neutral-300 ring-1 ring-white/10 hover:bg-black/70 hover:text-amber-200",
        box,
        className
      )}
    >
      <Star
        className={cn(dim, active && "fill-amber-300")}
      />
    </button>
  );
}
