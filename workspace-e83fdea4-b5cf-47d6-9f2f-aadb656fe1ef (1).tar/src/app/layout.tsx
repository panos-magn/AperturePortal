import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ErrorBoundary } from "@/components/gate/error-boundary";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Aperture — Client Media Portal",
  description: "Secure, high-performance web gallery backed by Google Drive. Images are streamed through a server-side proxy; Drive URLs are never exposed.",
  keywords: ["gallery", "Google Drive", "media portal", "secure image proxy", "Next.js"],
  authors: [{ name: "Aperture" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Aperture — Client Media Portal",
    description: "Secure Drive-backed gallery with server-side image proxy and TTL caching.",
    siteName: "Aperture",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Aperture — Client Media Portal",
    description: "Secure Drive-backed gallery with server-side image proxy and TTL caching.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ErrorBoundary>
          {children}
        </ErrorBoundary>
        <Toaster />
      </body>
    </html>
  );
}
