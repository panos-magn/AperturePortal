import { NextResponse } from "next/server";
import {
  evictGalleryCache,
  evictAllGalleryCaches,
  galleryCacheStats,
} from "@/lib/gallery/google-drive-service";
import type {
  CacheStatsResponse,
  CacheEvictResponse,
} from "@/lib/gallery/types";

export const dynamic = "force-dynamic";

/**
 * Cache management endpoint.
 *
 * GET    /api/gallery/cache              -> current stats (list + byte caches)
 * POST   /api/gallery/cache              -> evict ALL gallery caches (list + bytes)
 * POST   /api/gallery/cache?scope=list   -> evict only the file-list cache
 * POST   /api/gallery/cache?scope=bytes  -> evict only the byte cache
 * POST   /api/gallery/cache?evict=1      -> alias for full evict (back-compat)
 *
 * Mirrors the Spring "automated eviction interval" but exposed as an explicit
 * REST hook so an operator (or a cron) can force-refresh on demand.
 */
export async function GET() {
  const stats = galleryCacheStats();
  const body: CacheStatsResponse & {
    byteCacheSize?: number;
    byteCacheMaxBytes?: number;
    byteCacheBytes?: number;
  } = {
    size: stats.size,
    max: stats.max,
    ttlMs: stats.ttlMs,
    calculatedSize: stats.calculatedSize,
    byteCacheSize: stats.byteCacheSize,
    byteCacheMaxBytes: stats.byteCacheMaxBytes,
    byteCacheBytes: stats.byteCacheBytes,
  };
  return NextResponse.json({ stats: body }, {
    headers: { "Cache-Control": "no-store" },
  });
}

export async function POST(request: Request) {
  const url = new URL(request.url);
  const scope = url.searchParams.get("scope"); // 'list' | 'bytes' | undefined
  const evictFlag = url.searchParams.get("evict") === "1";

  let evicted = 0;
  let detail: { list?: number; bytes?: number } | undefined;

  if (scope === "list") {
    evicted = evictGalleryCache();
  } else if (scope === "bytes") {
    const all = evictAllGalleryCaches();
    evicted = all.bytes;
    detail = { list: 0, bytes: all.bytes };
  } else {
    // default / ?evict=1 -> evict everything
    void evictFlag;
    const all = evictAllGalleryCaches();
    evicted = all.list + all.bytes;
    detail = { list: all.list, bytes: all.bytes };
  }

  const body: CacheEvictResponse = {
    ok: true,
    evicted,
    stats: galleryCacheStats(),
    evictedAt: new Date().toISOString(),
  };
  const resp: Record<string, unknown> = { ...body };
  if (detail) resp.detail = detail;
  return NextResponse.json(resp);
}
