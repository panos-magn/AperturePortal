import { NextResponse } from "next/server";
import {
  listGallery,
  evictGalleryCache,
  galleryCacheStats,
  driveInitError,
} from "@/lib/gallery/google-drive-service";
import { getGalleryConfig } from "@/lib/gallery/config";
import type { GalleryListResponse } from "@/lib/gallery/types";

export const dynamic = "force-dynamic";
export const revalidate = 0;

/**
 * GET /api/gallery
 *
 * Returns the cached list of gallery images. In DEMO mode the list is the
 * bundled sample set; in LIVE mode it is fetched from Google Drive and then
 * cached for GALLERY_CACHE_TTL_MS (default 10 minutes).
 *
 * Query params:
 *   - bust=1        -> evict the cache before reading (manual refresh)
 *   - folderId=X    -> query a specific client subfolder (per-client gallery)
 */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const bust = url.searchParams.get("bust") === "1";
  const folderId = url.searchParams.get("folderId") || undefined;

  if (bust) {
    evictGalleryCache(folderId);
  }

  const cfg = getGalleryConfig();

  try {
    const { items, source, cached, folderId: usedFolderId } = await listGallery(folderId);

    const body: GalleryListResponse = {
      items,
      source,
      demo: source === "demo",
      cached,
      cacheTtlMs: cfg.cacheTtlMs,
      folderId: usedFolderId,
      fetchedAt: new Date().toISOString(),
      count: items.length,
      driveInitError: driveInitError(),
      credentialsPresent: cfg.credentialsExist,
    };
    // Help the browser/CDN avoid caching the *list* (the server cache is the
    // source of truth so newly uploaded images surface after TTL eviction).
    return NextResponse.json(body, {
      headers: {
        "Cache-Control": "no-store, max-age=0",
      },
    });
  } catch (e) {
    const msg = (e as Error).message;
    return NextResponse.json(
      {
        error: "Failed to load gallery",
        detail: msg,
        driveInitError: driveInitError(),
        stats: galleryCacheStats(),
      },
      { status: 502 }
    );
  }
}

/**
 * DELETE /api/gallery?folderId=...
 *
 * Force-evict the gallery cache. Optionally scope to a single folder.
 */
export async function DELETE() {
  const removed = evictGalleryCache();
  return NextResponse.json({ evicted: removed, stats: galleryCacheStats() });
}
