import { NextResponse } from "next/server";
import { ZipArchive } from "archiver";
import { getFileBytes } from "@/lib/gallery/google-drive-service";
import { isDemoId } from "@/lib/gallery/demo-data";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * POST /api/gallery/download
 * Body: { ids: string[], filename?: string }
 *
 * Streams a ZIP archive of the selected images. Each image is fetched via
 * the secure proxy (reusing the byte cache), so no Drive URLs are exposed
 * and repeat zips of the same set are fast.
 *
 * Returns a streaming `application/zip` response.
 */
export async function POST(request: Request) {
  let body: { ids?: string[]; filename?: string } = {};
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON body" },
      { status: 400 }
    );
  }

  const ids = Array.isArray(body.ids) ? body.ids.filter(Boolean) : [];
  if (ids.length === 0) {
    return NextResponse.json(
      { error: "No file ids provided" },
      { status: 400 }
    );
  }

  const archiveName =
    (body.filename && body.filename.trim()) || "aperture-gallery";
  const safeName = archiveName.replace(/[^a-z0-9-_]+/gi, "_").slice(0, 60);

  // Build the zip stream (archiver v8 uses named export ZipArchive).
  const archive = new ZipArchive({ zlib: { level: 6 } });

  // We'll pipe the archive into a web ReadableStream.
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      archive.on("data", (chunk: Buffer) => {
        controller.enqueue(new Uint8Array(chunk));
      });
      archive.on("end", () => controller.close());
      archive.on("error", (err: unknown) => controller.error(err));
    },
    cancel() {
      archive.destroy();
    },
  });

  // Append each selected file. Sequential to respect memory; the byte cache
  // makes repeats instant.
  (async () => {
    const usedNames = new Set<string>();
    for (const id of ids) {
      try {
        const { buffer, mimeType } = await getFileBytes(id);
        const ext = mimeType.split("/")[1] || "bin";
        // De-duplicate filenames within the zip.
        let name = `${id}.${ext}`;
        if (usedNames.has(name)) {
          name = `${id}-${Date.now()}.${ext}`;
        }
        usedNames.add(name);
        archive.append(buffer, { name });
      } catch {
        // Skip files that fail to fetch (e.g. demo id not found).
        if (isDemoId(id)) {
          archive.append(
            Buffer.from(`Failed to fetch ${id}\n`, "utf-8"),
            { name: `${id}.error.txt` }
          );
        }
      }
    }
    archive.finalize();
  })().catch(() => {
    archive.destroy();
  });

  return new NextResponse(stream as unknown as BodyInit, {
    status: 200,
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="${safeName}.zip"`,
      "Cache-Control": "no-store",
    },
  });
}
