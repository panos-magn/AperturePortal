import { NextResponse } from "next/server";
import {
  getGalleryConfig,
  setRuntimeTtl,
  getRuntimeTtl,
  TTL_LIMITS,
} from "@/lib/gallery/config";
import { galleryCacheStats, evictGalleryCache } from "@/lib/gallery/google-drive-service";

export const dynamic = "force-dynamic";

/**
 * Gallery runtime configuration endpoint.
 *
 * GET  /api/gallery/config            -> current config + effective TTL + limits
 * POST /api/gallery/config {ttlMs}    -> set a runtime TTL override (clamped)
 * POST /api/gallery/config {ttlMs:null}-> clear the override (revert to env)
 *
 * The TTL override takes precedence over GALLERY_CACHE_TTL_MS, applies to the
 * list cache immediately (the cache is rebuilt + evicted on change), and lets
 * an operator tune the cache window from the admin panel without a redeploy.
 */
export async function GET() {
  const cfg = getGalleryConfig();
  return NextResponse.json(
    {
      cacheTtlMs: cfg.cacheTtlMs,
      envTtlMs: Number.parseInt(process.env.GALLERY_CACHE_TTL_MS || "600000", 10) || 600000,
      runtimeOverrideMs: getRuntimeTtl(),
      limits: TTL_LIMITS,
      demoMode: cfg.demoMode,
      folderId: cfg.folderId || null,
      stats: galleryCacheStats(),
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}

export async function POST(request: Request) {
  let body: { ttlMs?: number | null } = {};
  try {
    body = await request.json();
  } catch {
    /* empty body is allowed (acts as a no-op read) */
  }

  const requested = body.ttlMs;
  const effective = setRuntimeTtl(
    typeof requested === "number" ? requested : null
  );

  // Rebuild + evict so the new TTL applies immediately.
  evictGalleryCache();

  const cfg = getGalleryConfig();
  return NextResponse.json(
    {
      ok: true,
      cacheTtlMs: cfg.cacheTtlMs,
      runtimeOverrideMs: getRuntimeTtl(),
      effectiveTtlMs: effective,
      limits: TTL_LIMITS,
      stats: galleryCacheStats(),
      appliedAt: new Date().toISOString(),
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}
