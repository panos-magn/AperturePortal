import { NextResponse } from "next/server";
import { healthCheck } from "@/lib/gallery/google-drive-service";
import type { GalleryHealthResponse } from "@/lib/gallery/types";

export const dynamic = "force-dynamic";

/**
 * GET /api/gallery/health
 *
 * Returns a diagnostic snapshot of the gallery backend:
 *  - mode (demo | google-drive)
 *  - whether credentials are present
 *  - whether the Drive client initialised
 *  - list-cache + byte-cache stats
 *  - optional `?ping=1` performs a 1-file Drive list to verify access
 */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const ping = url.searchParams.get("ping") === "1";
  const result: GalleryHealthResponse = await healthCheck({ ping });
  const status =
    result.status === "ok" ? 200 : result.status === "degraded" ? 200 : 503;
  return NextResponse.json(result, {
    status,
    headers: { "Cache-Control": "no-store" },
  });
}
