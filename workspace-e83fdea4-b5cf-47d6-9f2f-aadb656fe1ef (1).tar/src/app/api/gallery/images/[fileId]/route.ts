import { NextResponse } from "next/server";
import { getFileBytes } from "@/lib/gallery/google-drive-service";
import { isDemoId } from "@/lib/gallery/demo-data";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Secure Image Proxy Controller
 * GET /api/gallery/images/[fileId]
 *
 * Streams image bytes from the backend to the client with the correct
 * Content-Type header. Google Drive internal URLs are NEVER exposed to the
 * frontend — the browser only ever talks to this endpoint.
 *
 * Supports HTTP Range requests (206 Partial Content) so large images and
 * video seeking work correctly. Uses a per-file byte cache to avoid
 * repeat Drive API calls.
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ fileId: string }> }
) {
  const { fileId } = await params;
  if (!fileId) {
    return new NextResponse("Missing fileId", { status: 400 });
  }

  let bytes: Buffer;
  let mimeType: string;
  let size: number | undefined;

  try {
    const result = await getFileBytes(fileId);
    if (!result.buffer) {
      throw new Error("Stream mode not supported after caching refactor");
    }
    bytes = result.buffer;
    mimeType = result.mimeType;
    size = result.size ?? bytes.length;
  } catch (e) {
    const msg = (e as Error).message;
    const status =
      isDemoId(fileId) && msg.includes("not found") ? 404 : 502;
    return new NextResponse(
      JSON.stringify({ error: "image_unavailable", detail: msg }),
      { status, headers: { "Content-Type": "application/json" } }
    );
  }

  const total = size ?? bytes.length;

  // ---- Range request handling (HTTP 206 Partial Content) ----
  const rangeHeader = request.headers.get("range");
  if (rangeHeader && rangeHeader.startsWith("bytes=")) {
    const m = /bytes=(\d*)-(\d*)/.exec(rangeHeader);
    if (m) {
      const startStr = m[1];
      const endStr = m[2];
      let start = startStr ? parseInt(startStr, 10) : 0;
      let end = endStr ? parseInt(endStr, 10) : total - 1;
      if (Number.isNaN(start) || Number.isNaN(end)) {
        return new NextResponse(null, {
          status: 416,
          headers: { "Content-Range": `bytes */${total}` },
        });
      }
      if (start >= total) {
        return new NextResponse(null, {
          status: 416,
          headers: { "Content-Range": `bytes */${total}` },
        });
      }
      if (end >= total) end = total - 1;
      const chunk = bytes.subarray(start, end + 1);
      const headers: Record<string, string> = {
        "Content-Type": mimeType,
        "Content-Length": String(chunk.length),
        "Content-Range": `bytes ${start}-${end}/${total}`,
        "Accept-Ranges": "bytes",
        "Cache-Control": "public, max-age=3600, immutable",
        "X-Content-Type-Options": "nosniff",
      };
      return new NextResponse(chunk as unknown as BodyInit, {
        status: 206,
        headers,
      });
    }
  }

  // ---- Full response ----
  const headers: Record<string, string> = {
    "Content-Type": mimeType,
    "Content-Length": String(total),
    "Accept-Ranges": "bytes",
    // Browser + CDN caching of the *image bytes* is safe and desirable:
    // the bytes don't change for a given fileId, and this dramatically
    // cuts repeat Drive API calls.
    "Cache-Control": "public, max-age=3600, immutable",
    "X-Content-Type-Options": "nosniff",
  };

  return new NextResponse(bytes as unknown as BodyInit, {
    status: 200,
    headers,
  });
}

/** HEAD support for range/size probing without transferring bytes. */
export async function HEAD(
  _request: Request,
  { params }: { params: Promise<{ fileId: string }> }
) {
  const { fileId } = await params;
  if (!fileId) return new NextResponse(null, { status: 400 });
  try {
    const result = await getFileBytes(fileId);
    const total = result.size ?? result.buffer?.length ?? 0;
    return new NextResponse(null, {
      status: 200,
      headers: {
        "Content-Type": result.mimeType,
        "Content-Length": String(total),
        "Accept-Ranges": "bytes",
        "Cache-Control": "public, max-age=3600, immutable",
      },
    });
  } catch {
    return new NextResponse(null, { status: 502 });
  }
}
