import { NextResponse } from "next/server";
import { getImageMeta } from "@/lib/gallery/google-drive-service";
import { isDemoId } from "@/lib/gallery/demo-data";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * GET /api/gallery/images/[fileId]/meta
 *
 * Returns image dimensions + format (probed via sharp from the cached byte
 * buffer). Used by the lightbox caption to show "1920×1080 · jpeg".
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ fileId: string }> }
) {
  const { fileId } = await params;
  if (!fileId) {
    return NextResponse.json({ error: "Missing fileId" }, { status: 400 });
  }

  try {
    const meta = await getImageMeta(fileId);
    return NextResponse.json(meta, {
      headers: {
        // Metadata is immutable for a fileId, so cache aggressively.
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (e) {
    const msg = (e as Error).message;
    const status = isDemoId(fileId) && msg.includes("not found") ? 404 : 502;
    return NextResponse.json(
      { error: "meta_unavailable", detail: msg },
      { status }
    );
  }
}
