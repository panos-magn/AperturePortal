import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * POST /api/auth
 * Body: { pin: string }
 *
 * Validates the supplied PIN against the ACCESS_PIN env var. On success,
 * sets an httpOnly cookie `aperture_token` (valid for 30 days) and returns
 * `{ ok: true }`. On failure returns 401.
 *
 * If no ACCESS_PIN is configured, auth is disabled (open access).
 */
export async function POST(request: Request) {
  let body: { pin?: string } = {};
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const configuredPin = process.env.ACCESS_PIN || "";
  // If no PIN is configured, the portal is open (no auth required).
  if (!configuredPin) {
    return NextResponse.json({ ok: true, open: true });
  }

  const supplied = body.pin || "";
  if (supplied === configuredPin) {
    const res = NextResponse.json({ ok: true });
    // 30-day cookie, httpOnly so JS can't read it (XSS protection).
    res.cookies.set("aperture_token", configuredPin, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 30,
      path: "/",
    });
    return res;
  }

  return NextResponse.json({ error: "Invalid PIN" }, { status: 401 });
}

/**
 * GET /api/auth — check if the current request is authenticated.
 */
export async function GET(request: Request) {
  const configuredPin = process.env.ACCESS_PIN || "";
  if (!configuredPin) {
    return NextResponse.json({ authenticated: true, open: true });
  }
  const cookie = request.headers.get("cookie") || "";
  const token = cookie
    .split("; ")
    .find((c) => c.startsWith("aperture_token="))
    ?.split("=")[1];
  return NextResponse.json({ authenticated: token === configuredPin });
}

/**
 * DELETE /api/auth — log out (clear the cookie).
 */
export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.delete("aperture_token");
  return res;
}
