import { NextResponse } from "next/server";
import { listClientFolders } from "@/lib/gallery/google-drive-service";
import {
  ensureClient,
  getAllClients,
  regenerateCode,
  validateClientCode,
} from "@/lib/gallery/client-store";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * GET /api/clients
 *   Admin: lists all client folders + their access codes.
 *   Requires the admin ACCESS_PIN cookie.
 *
 * GET /api/clients?folderId=X&code=Y
 *   Client: validates a client access code (used by the client gallery gate).
 */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const folderId = url.searchParams.get("folderId");
  const code = url.searchParams.get("code");

  // Client code validation
  if (folderId && code) {
    const valid = validateClientCode(folderId, code);
    if (valid) {
      const res = NextResponse.json({ ok: true });
      // Set a per-client cookie (30 days).
      res.cookies.set(`aperture_client_${folderId}`, code, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 30,
        path: "/",
      });
      return res;
    }
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  // Admin list — require admin auth.
  const adminPin = process.env.ACCESS_PIN || "";
  const cookie = request.headers.get("cookie") || "";
  const adminToken = cookie
    .split("; ")
    .find((c) => c.startsWith("aperture_token="))
    ?.split("=")[1];
  if (adminPin && adminToken !== adminPin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const folders = await listClientFolders();
    const store = getAllClients();
    // Ensure every folder has a record (auto-generate codes for new clients).
    const clients = folders.map((f) => {
      const record = ensureClient(f.id, f.name);
      return {
        id: f.id,
        name: f.name,
        createdTime: f.createdTime,
        code: record.code,
        codeCreatedAt: record.createdAt,
      };
    });
    return NextResponse.json({ clients });
  } catch (e) {
    return NextResponse.json(
      { error: "Failed to list clients", detail: (e as Error).message },
      { status: 502 }
    );
  }
}

/**
 * POST /api/clients
 * Body: { folderId, action: "regenerate" }
 * Regenerates the access code for a client.
 */
export async function POST(request: Request) {
  // Require admin auth.
  const adminPin = process.env.ACCESS_PIN || "";
  const cookie = request.headers.get("cookie") || "";
  const adminToken = cookie
    .split("; ")
    .find((c) => c.startsWith("aperture_token="))
    ?.split("=")[1];
  if (adminPin && adminToken !== adminPin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: { folderId?: string; action?: string } = {};
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (body.action === "regenerate" && body.folderId) {
    const record = regenerateCode(body.folderId);
    if (!record) {
      return NextResponse.json({ error: "Client not found" }, { status: 404 });
    }
    return NextResponse.json({ ok: true, code: record.code });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
