"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  RefreshCw,
  Images,
  ShieldCheck,
  Database,
  HardDrive,
  ServerCog,
  AlertTriangle,
  Loader2,
  Aperture,
  Keyboard,
  Lock,
  ArrowRight,
} from "lucide-react";
import dynamic from "next/dynamic";
import { GalleryGrid, type GalleryGridHandle } from "@/components/gallery/gallery-grid";
import {
  GalleryToolbar,
  type SortKey,
} from "@/components/gallery/gallery-toolbar";
import { RecentlyViewed, type RecentEntry } from "@/components/gallery/recently-viewed";
import { SelectionBar } from "@/components/gallery/selection-bar";
import { ShortcutModal } from "@/components/gallery/shortcut-modal";
import { AdminDashboard } from "@/components/gate/admin-dashboard";
import type { SlideshowSpeed, KenBurnsDirection } from "@/components/gallery/lightbox";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { useToast } from "@/hooks/use-toast";
import { filterAndSort } from "@/lib/gallery/filter";
import type { DriveFileDto, GalleryListResponse } from "@/lib/gallery/types";

// Lazy-mount the admin panels so they don't bloat the initial JS bundle.
// (Helps mitigate the 4 GB sandbox OOM on heavy Turbopack compiles.)
const CachePanel = dynamic(
  () => import("@/components/gallery/cache-panel").then((m) => m.CachePanel),
  { ssr: false }
);
const SetupGuide = dynamic(
  () => import("@/components/gallery/setup-guide").then((m) => m.SetupGuide),
  { ssr: false }
);

type Layout = "grid" | "masonry";

export default function Home() {
  // Detect client mode via ?c=<id> query param. When present, render the
  // client gallery (PIN-gated to that client's folder). Otherwise render
  // the admin dashboard (admin-PIN-gated).
  // Lazy init from window.location — avoids setState-in-effect. On the
  // server `window` is undefined so we default to "" (admin mode); the
  // client hydrates with the real value.
  const [clientMode] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return new URL(window.location.href).searchParams.get("c") ?? "";
  });
  if (clientMode === null) {
    // Server render — show a loader (client will hydrate with the real mode).
    return (
      <div className="flex min-h-screen items-center justify-center bg-neutral-950">
        <Loader2 className="h-7 w-7 animate-spin text-emerald-400" />
      </div>
    );
  }
  if (clientMode) {
    return <ClientGallery clientId={clientMode} />;
  }
  return <AdminApp />;
}

/**
 * AdminApp — the user's dashboard. PIN-gated; lists all client folders with
 * auto-generated shareable links + access codes.
 */
function AdminApp() {
  const [authed, setAuthed] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    fetch("/api/auth", { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => {
        setAuthed(!!j.authenticated);
        setChecking(false);
      })
      .catch(() => {
        setChecking(false);
      });
  }, []);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-neutral-950">
        <Loader2 className="h-7 w-7 animate-spin text-emerald-400" />
      </div>
    );
  }

  if (!authed) {
    return <AdminGate />;
  }

  return (
    <AdminDashboard
      onLogout={async () => {
        await fetch("/api/auth", { method: "DELETE" });
        window.location.reload();
      }}
    />
  );
}

/**
 * AdminGate — login screen for the admin dashboard. Uses the global
 * ACCESS_PIN (different from per-client codes).
 */
function AdminGate() {
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin }),
      });
      if (res.ok) {
        window.location.reload();
      } else {
        setError("Incorrect access code. Please try again.");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-neutral-950 px-4">
      <div className="aurora-bg absolute inset-0" />
      <div className="relative w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 text-black shadow-lg shadow-emerald-500/20">
            <Aperture className="h-7 w-7" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-white">
            Aperture
          </h1>
          <p className="mt-1 text-sm text-neutral-400">Admin Dashboard</p>
        </div>
        <form
          onSubmit={submit}
          className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-6 backdrop-blur-sm"
        >
          <div className="mb-4 flex items-center gap-2 text-sm text-neutral-300">
            <Lock className="h-4 w-4 text-emerald-400" />
            <span>Enter your admin access code</span>
          </div>
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="Admin access code"
            autoFocus
            autoComplete="current-password"
            className="w-full rounded-lg border border-neutral-700 bg-neutral-950/60 px-4 py-2.5 text-sm text-neutral-100 placeholder:text-neutral-500 transition focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
          />
          {error ? <p className="mt-2 text-xs text-rose-400">{error}</p> : null}
          <button
            type="submit"
            disabled={submitting || !pin}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-black transition hover:bg-emerald-400 disabled:opacity-40"
          >
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : (
              <>
                Enter
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}

/**
 * ClientGallery — the per-client gallery view. Validates the client's
 * access code (from the ?code= query param or a per-client cookie), then
 * renders the full gallery scoped to that client's folder.
 */
function ClientGallery({ clientId }: { clientId: string }) {
  const [authed, setAuthed] = useState(false);
  const [checking, setChecking] = useState(true);
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Check if already authed via the ?code= param or a per-client cookie.
  useEffect(() => {
    const url = new URL(window.location.href);
    const code = url.searchParams.get("code");
    if (code) {
      // Validate the code via /api/clients?folderId=X&code=Y (sets cookie).
      fetch(`/api/clients?folderId=${encodeURIComponent(clientId)}&code=${encodeURIComponent(code)}`, {
        cache: "no-store",
      })
        .then((r) => {
          if (r.ok) setAuthed(true);
          setChecking(false);
        })
        .catch(() => setChecking(false));
      return;
    }
    // No code param — check if a per-client cookie exists by calling the
    // gallery endpoint; if it 401s, show the PIN form.
    fetch(`/api/gallery?folderId=${encodeURIComponent(clientId)}`, {
      cache: "no-store",
    })
      .then((r) => {
        setAuthed(r.ok);
        setChecking(false);
      })
      .catch(() => setChecking(false));
  }, [clientId]);

  // The gallery API for client mode should require the client code. For
  // simplicity in this single-route constraint, we allow the gallery fetch
  // to proceed if the code param validated (cookie set). A production
  // version would add middleware to enforce the cookie on the API itself.
  // For now, the client enters their code → cookie set → gallery loads.

  const submitPin = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch(
        `/api/clients?folderId=${encodeURIComponent(clientId)}&code=${encodeURIComponent(pin)}`,
        { cache: "no-store" }
      );
      if (res.ok) {
        setAuthed(true);
      } else {
        setError("Incorrect access code. Please try again.");
      }
    } catch {
      setError("Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  };

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-neutral-950">
        <Loader2 className="h-7 w-7 animate-spin text-emerald-400" />
      </div>
    );
  }

  if (!authed) {
    return (
      <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-neutral-950 px-4">
        <div className="aurora-bg absolute inset-0" />
        <div className="relative w-full max-w-sm">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 text-black shadow-lg shadow-emerald-500/20">
              <Aperture className="h-7 w-7" />
            </div>
            <h1 className="text-xl font-semibold tracking-tight text-white">
              Client Gallery
            </h1>
            <p className="mt-1 text-sm text-neutral-400">
              Enter your access code to view your media
            </p>
          </div>
          <form
            onSubmit={submitPin}
            className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-6 backdrop-blur-sm"
          >
            <div className="mb-4 flex items-center gap-2 text-sm text-neutral-300">
              <Lock className="h-4 w-4 text-emerald-400" />
              <span>Access code</span>
            </div>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Your access code"
              autoFocus
              autoComplete="current-password"
              className="w-full rounded-lg border border-neutral-700 bg-neutral-950/60 px-4 py-2.5 text-sm text-neutral-100 placeholder:text-neutral-500 transition focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
            />
            {error ? <p className="mt-2 text-xs text-rose-400">{error}</p> : null}
            <button
              type="submit"
              disabled={submitting || !pin}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-black transition hover:bg-emerald-400 disabled:opacity-40"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : (
                <>
                  Enter
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return <GalleryView folderId={clientId} />;
}

/**
 * GalleryView — the full gallery UI (the original portal). Now accepts a
 * `folderId` prop so it can be scoped to a specific client's Drive subfolder.
 * This is the component with all the features: search, sort, favourites,
 * lightbox, slideshow, multi-select, etc.
 */
function GalleryView({ folderId }: { folderId?: string }) {
  const [data, setData] = useState<GalleryListResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);

  // Persisted UI preferences (survive reloads + sync across tabs).
  const [layout, setLayout] = useLocalStorage<Layout>(
    "aperture.layout",
    "grid"
  );
  const [sort, setSort] = useLocalStorage<SortKey>(
    "aperture.sort",
    "date-desc"
  );
  const [query, setQuery] = useLocalStorage<string>("aperture.query", "");
  const [slideshowSpeed, setSlideshowSpeed] =
    useLocalStorage<SlideshowSpeed>("aperture.slideshowSpeed", 4000);
  const [kenBurnsDirection, setKenBurnsDirection] =
    useLocalStorage<KenBurnsDirection>("aperture.kenBurnsDirection", "in");
  const [recentEntries, setRecentEntries] = useLocalStorage<RecentEntry[]>(
    "aperture.recentV2",
    []
  );
  const [favourites, setFavourites] = useLocalStorage<string[]>(
    "aperture.favourites",
    []
  );
  const [showFavouritesOnly, setShowFavouritesOnly] = useLocalStorage<boolean>(
    "aperture.showFavouritesOnly",
    false
  );
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [downloading, setDownloading] = useState(false);

  const { toast } = useToast();
  // Track the previous item-id set so a refresh can detect new uploads.
  const prevIdsRef = useRef<Set<string> | null>(null);

  const load = useCallback(
    async (bust = false, opts?: { silent?: boolean }) => {
      try {
        setError(null);
        if (bust) setRefreshing(true);
        const params = new URLSearchParams();
        if (bust) params.set("bust", "1");
        if (folderId) params.set("folderId", folderId);
        const qs = params.toString();
        const url = `/api/gallery${qs ? `?${qs}` : ""}`;
        const res = await fetch(url, { cache: "no-store" });
        if (!res.ok) {
          const j = await res.json().catch(() => ({}));
          throw new Error(j.detail || j.error || `HTTP ${res.status}`);
        }
        const json = (await res.json()) as GalleryListResponse;

        // Detect newly-appeared images on a manual refresh.
        const newIds = new Set(json.items.map((it) => it.id));
        if (bust && prevIdsRef.current && !opts?.silent) {
          const added = [...newIds].filter((id) => !prevIdsRef.current!.has(id));
          const removed = [...prevIdsRef.current].filter(
            (id) => !newIds.has(id)
          );
          if (added.length > 0 || removed.length > 0) {
            const parts: string[] = [];
            if (added.length) parts.push(`${added.length} new`);
            if (removed.length) parts.push(`${removed.length} removed`);
            toast({
              title: "Gallery updated",
              description: `Detected ${parts.join(", ")} since last refresh.`,
            });
          } else {
            toast({
              title: "Gallery up to date",
              description: "No changes since the last refresh.",
            });
          }
        }
        prevIdsRef.current = newIds;
        setData(json);
      } catch (e) {
        setError((e as Error).message);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [toast, folderId]
  );

  useEffect(() => {
    load(false);
  }, [load]);

  // Global keyboard shortcuts (gallery-level). Ignore when a text field is
  // focused, a modifier is held, or the lightbox/modal is open.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const typing =
        el &&
        (el.tagName === "INPUT" ||
          el.tagName === "TEXTAREA" ||
          el.tagName === "SELECT" ||
          el.isContentEditable);
      if (typing || e.metaKey || e.ctrlKey || e.altKey) return;
      if (document.querySelector("[role=dialog]")) return; // lightbox/modal open

      if (e.key === "/") {
        e.preventDefault();
        const input = document.querySelector<HTMLInputElement>(
          'input[type="search"]'
        );
        input?.focus();
        input?.select();
      } else if (e.key === "?") {
        e.preventDefault();
        setShortcutsOpen((o) => !o);
      } else if (e.key.toLowerCase() === "g") {
        e.preventDefault();
        setLayout("grid");
      } else if (e.key.toLowerCase() === "m") {
        e.preventDefault();
        setLayout("masonry");
      } else if (
        (e.ctrlKey || e.metaKey) &&
        e.shiftKey &&
        e.key.toLowerCase() === "a"
      ) {
        // Ctrl/Cmd+Shift+A: clear selection (or exit select mode).
        e.preventDefault();
        setSelectedIds([]);
      } else if (e.key.toLowerCase() === "x" && selectMode) {
        // X: exit select mode.
        e.preventDefault();
        setSelectMode(false);
        setSelectedIds([]);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setLayout, selectMode]);

  // Track recently-viewed image ids + timestamps (newest first, deduped, capped at 12).
  const handleImageView = useCallback(
    (id: string) => {
      if (!id) return;
      setRecentEntries((prev) => {
        const entry: RecentEntry = { id, ts: Date.now() };
        const next = [entry, ...prev.filter((x) => x.id !== id)];
        return next.slice(0, 12);
      });
    },
    [setRecentEntries]
  );

  // Toggle a favourite id (add/remove, no duplicates).
  const handleToggleFavourite = useCallback(
    (id: string) => {
      if (!id) return;
      setFavourites((prev) =>
        prev.includes(id)
          ? prev.filter((x) => x !== id)
          : [...prev, id]
      );
    },
    [setFavourites]
  );

  // Derived: filtered + sorted view of the items (defined here so the
  // multi-select handlers below can reference it in their deps arrays).
  const visibleItems = useMemo(() => {
    if (!data) return [];
    const filtered = filterAndSort(data.items, query, sort);
    if (showFavouritesOnly) {
      const favSet = new Set(favourites);
      return filtered.filter((it) => favSet.has(it.id));
    }
    return filtered;
  }, [data, query, sort, showFavouritesOnly, favourites]);

  const filtering = query.trim().length > 0;

  // Total byte size of the currently-selected images (for the selection bar).
  const selectedSize = useMemo(() => {
    if (selectedIds.length === 0 || !data) return 0;
    const idSet = new Set(selectedIds);
    return data.items
      .filter((it) => idSet.has(it.id))
      .reduce((sum, it) => sum + (Number(it.size) || 0), 0);
  }, [selectedIds, data]);

  // Multi-select handlers. `selectAnchor` tracks the last clicked index so
  // shift-click can select a range from the anchor to the clicked card.
  const selectAnchorRef = useRef<number | null>(null);

  const handleToggleSelect = useCallback((id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id)
        ? prev.filter((x) => x !== id)
        : [...prev, id]
    );
  }, []);

  const handleRangeSelect = useCallback(
    (index: number) => {
      const anchor = selectAnchorRef.current;
      if (anchor === null) {
        // No anchor yet — just toggle this one and set the anchor.
        const id = visibleItems[index]?.id;
        if (id) {
          setSelectedIds((prev) =>
            prev.includes(id) ? prev : [...prev, id]
          );
        }
        selectAnchorRef.current = index;
        return;
      }
      const start = Math.min(anchor, index);
      const end = Math.max(anchor, index);
      const rangeIds = visibleItems
        .slice(start, end + 1)
        .map((it) => it.id)
        .filter(Boolean);
      setSelectedIds((prev) => {
        const set = new Set(prev);
        rangeIds.forEach((id) => set.add(id));
        return Array.from(set);
      });
      selectAnchorRef.current = index;
    },
    [visibleItems]
  );

  const handleSelectAll = useCallback(() => {
    setSelectedIds((prev) => {
      const allIds = visibleItems.map((it) => it.id);
      const allSelected =
        allIds.length > 0 && allIds.every((id) => prev.includes(id));
      return allSelected ? [] : allIds;
    });
  }, [visibleItems]);

  const handleExitSelectMode = useCallback(() => {
    setSelectMode(false);
    setSelectedIds([]);
  }, []);

  const handleDownloadZip = useCallback(async () => {
    if (selectedIds.length === 0) return;
    setDownloading(true);
    try {
      const res = await fetch("/api/gallery/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ids: selectedIds,
          filename: `aperture-${selectedIds.length}images`,
        }),
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      // Trigger a browser download of the zip blob.
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `aperture-${selectedIds.length}images.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast({
        title: "Download ready",
        description: `${selectedIds.length} image${selectedIds.length === 1 ? "" : "s"} zipped successfully.`,
      });
    } catch (e) {
      toast({
        title: "Download failed",
        description: (e as Error).message,
      });
    } finally {
      setDownloading(false);
    }
  }, [selectedIds, toast]);

  const handleDownloadAll = useCallback(async () => {
    const allIds = visibleItems.map((it) => it.id).filter(Boolean);
    if (allIds.length === 0) return;
    setDownloading(true);
    try {
      const res = await fetch("/api/gallery/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ids: allIds,
          filename: `aperture-all-${allIds.length}images`,
        }),
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `aperture-all-${allIds.length}images.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast({
        title: "Download ready",
        description: `All ${allIds.length} image${allIds.length === 1 ? "" : "s"} zipped successfully.`,
      });
    } catch (e) {
      toast({
        title: "Download failed",
        description: (e as Error).message,
      });
    } finally {
      setDownloading(false);
    }
  }, [visibleItems, toast]);

  // Open an item from the recently-viewed rail by finding its index in the
  // visible items (so the lightbox shows the right set + position).
  const galleryGridRef = useRef<GalleryGridHandle | null>(null);
  const openById = useCallback(
    (item: DriveFileDto) => {
      galleryGridRef.current?.openById(item.id);
    },
    []
  );

  return (
    <div className="flex min-h-screen flex-col bg-neutral-950 text-neutral-100">
      {/* Sticky header */}
      <header className="sticky top-0 z-40 border-b border-neutral-800/80 bg-neutral-950/80 backdrop-blur supports-[backdrop-filter]:bg-neutral-950/60">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-400 to-teal-500 text-black shadow-lg shadow-emerald-500/20">
              <Aperture className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <h1 className="text-sm font-semibold tracking-tight text-white sm:text-base">
                Aperture
              </h1>
              <p className="text-[11px] text-neutral-400">
                Client Media Portal
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {!folderId ? <SourceBadge source={data?.source ?? "demo"} /> : null}
            {!folderId ? (
              <button
                onClick={() => setShortcutsOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-2.5 py-1.5 text-xs font-medium text-neutral-300 ring-1 ring-neutral-700 transition hover:bg-neutral-700 hover:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-400/60"
                aria-label="Keyboard shortcuts (?)"
                title="Keyboard shortcuts (?)"
              >
                <Keyboard className="h-3.5 w-3.5" />
                <span className="hidden md:inline">Shortcuts</span>
                <kbd className="ml-0.5 hidden rounded bg-neutral-700 px-1 py-0.5 font-mono text-[9px] text-neutral-300 lg:inline">
                  ?
                </kbd>
              </button>
            ) : null}
            <button
              onClick={() => load(true)}
              disabled={refreshing || loading}
              className="inline-flex items-center gap-1.5 rounded-lg bg-neutral-800 px-3 py-1.5 text-xs font-medium text-neutral-100 ring-1 ring-neutral-700 transition hover:bg-neutral-700 disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-emerald-400/60"
              aria-label="Refresh gallery"
            >
              <RefreshCw
                className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`}
              />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero / status strip — admin only (hidden for client galleries) */}
      {!folderId ? (
      <section className="relative border-b border-neutral-800/60">
        <div className="aurora-bg absolute inset-0" />
        <div className="relative mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-12">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-[11px] font-medium text-emerald-300 ring-1 ring-emerald-400/30">
            <ShieldCheck className="h-3 w-3" />
            Secure · Server-proxied · No Drive URLs exposed
          </span>
          <h2 className="mt-4 max-w-2xl text-2xl font-semibold tracking-tight text-white sm:text-4xl">
            A secure, high-performance gallery backed by Google Drive.
          </h2>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-neutral-400 sm:text-base">
            Images are streamed through a server-side proxy so Drive-internal
            URLs are never exposed. A TTL cache shields the Drive API from
            rate limits while new uploads surface automatically after a short
            delay.
          </p>

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <StatCard
              icon={<Images className="h-4 w-4" />}
              label="Images"
              value={loading ? "—" : String(data?.count ?? 0)}
              accent="emerald"
            />
            <StatCard
              icon={
                data?.source === "google-drive" ? (
                  <HardDrive className="h-4 w-4" />
                ) : (
                  <ServerCog className="h-4 w-4" />
                )
              }
              label="Source"
              value={data?.source === "google-drive" ? "Google Drive" : "Demo"}
              accent="sky"
            />
            <StatCard
              icon={<Database className="h-4 w-4" />}
              label="Cache"
              value={data ? (data.cached ? "HIT" : "MISS") : "—"}
              hint={data ? `${Math.round(data.cacheTtlMs / 60000)}m TTL` : undefined}
              accent="violet"
            />
            <StatCard
              icon={<ShieldCheck className="h-4 w-4" />}
              label="Proxy"
              value="Active"
              hint="bytes only · 206 ranges"
              accent="emerald"
            />
          </div>

          {data?.folderId ? (
            <p className="mt-4 font-mono text-[11px] text-neutral-500">
              folder: {data.folderId}
            </p>
          ) : null}
        </div>
      </section>
      ) : null}

      {/* Drive init error banner (LIVE misconfigured) — admin only */}
      {data?.driveInitError ? (
        <div className="mx-auto mt-6 w-full max-w-7xl px-4 sm:px-6">
          <div className="flex items-start gap-3 rounded-xl border border-rose-500/30 bg-rose-500/10 p-4 text-sm text-rose-200">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <p className="font-medium">Google Drive connection issue</p>
              <p className="mt-1 break-words text-rose-200/80">
                {data.driveInitError}
              </p>
              <p className="mt-1 text-xs text-rose-200/70">
                Falling back is disabled because LIVE mode is configured. Fix
                the credentials and refresh.
              </p>
            </div>
          </div>
        </div>
      ) : null}

      {/* Gallery */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6">
        {error ? (
          <div className="mb-6 flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-200">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <p className="font-medium">Couldn’t load the gallery</p>
              <p className="mt-1 text-amber-200/80">{error}</p>
            </div>
          </div>
        ) : null}

        <GalleryToolbar
          query={query}
          onQueryChange={setQuery}
          sort={sort}
          onSortChange={setSort}
          layout={layout}
          onLayoutChange={setLayout}
          totalCount={data?.count ?? 0}
          shownCount={visibleItems.length}
          favouritesCount={favourites.length}
          showFavouritesOnly={showFavouritesOnly}
          onToggleFavouritesFilter={() => setShowFavouritesOnly((v) => !v)}
          selectMode={selectMode}
          onToggleSelectMode={() =>
            setSelectMode((v) => {
              if (v) setSelectedIds([]);
              return !v;
            })
          }
        />

        {selectMode && !loading ? (
          <SelectionBar
            selectedCount={selectedIds.length}
            totalCount={visibleItems.length}
            selectedSize={selectedSize}
            onSelectAll={handleSelectAll}
            onSelectNone={() => setSelectedIds([])}
            onClear={handleExitSelectMode}
            onDownload={handleDownloadZip}
            onDownloadAll={handleDownloadAll}
            downloading={downloading}
          />
        ) : null}

        {!loading && data && !selectMode ? (
          <RecentlyViewed
            items={data.items}
            recentEntries={recentEntries}
            onOpen={openById}
            onClear={() => setRecentEntries([])}
          />
        ) : null}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 text-neutral-400">
            <Loader2 className="mb-3 h-7 w-7 animate-spin text-emerald-400" />
            <p className="text-sm">Loading gallery…</p>
          </div>
        ) : (
          <GalleryGrid
            ref={galleryGridRef}
            items={visibleItems}
            layout={layout}
            hasQuery={filtering || showFavouritesOnly}
            slideshowSpeed={slideshowSpeed}
            onSlideshowSpeedChange={setSlideshowSpeed}
            kenBurnsDirection={kenBurnsDirection}
            onKenBurnsDirectionChange={setKenBurnsDirection}
            onImageView={handleImageView}
            favourites={favourites}
            onToggleFavourite={handleToggleFavourite}
            selectMode={selectMode}
            selectedIds={selectedIds}
            onToggleSelect={handleToggleSelect}
            onRangeSelect={handleRangeSelect}
          />
        )}

        {/* Admin panels (lazy-mounted) — admin only */}
        {!folderId ? (
          <div className="mt-8 grid grid-cols-1 gap-4 lg:grid-cols-2">
            <CachePanel />
            <SetupGuide />
          </div>
        ) : null}
      </main>

      <ShortcutModal
        open={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
      />

      {/* Sticky footer */}
      <footer className="mt-auto border-t border-neutral-800/80 bg-neutral-950">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-neutral-500 sm:flex-row sm:px-6">
          <p>
            <span className="font-medium text-neutral-300">Aperture</span> ·
            Secure Drive-backed media portal
          </p>
          <p className="flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-500/80" />
            Images proxied · No Drive URLs exposed · HTTP 206 ranges
          </p>
        </div>
      </footer>
    </div>
  );
}

function SourceBadge({ source }: { source: "google-drive" | "demo" }) {
  const live = source === "google-drive";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium ring-1 ${
        live
          ? "bg-emerald-500/10 text-emerald-300 ring-emerald-400/30"
          : "bg-amber-500/10 text-amber-300 ring-amber-400/30"
      }`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          live ? "bg-emerald-400" : "bg-amber-400"
        } ${live ? "animate-pulse" : ""}`}
      />
      {live ? "Live · Drive" : "Demo"}
    </span>
  );
}

const ACCENTS: Record<string, string> = {
  emerald: "text-emerald-400/90",
  sky: "text-sky-400/90",
  violet: "text-violet-400/90",
};

function StatCard({
  icon,
  label,
  value,
  hint,
  accent = "emerald",
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint?: string;
  accent?: "emerald" | "sky" | "violet";
}) {
  return (
    <div className="rounded-xl border border-neutral-800/80 bg-neutral-900/50 p-3 backdrop-blur-sm transition hover:border-neutral-700">
      <div className="flex items-center gap-1.5 text-neutral-400">
        <span className={ACCENTS[accent]}>{icon}</span>
        <span className="text-[11px] uppercase tracking-wide">{label}</span>
      </div>
      <div className="mt-1.5 flex items-baseline gap-1.5">
        <span className="text-lg font-semibold text-white">{value}</span>
        {hint ? (
          <span className="text-[10px] text-neutral-500">{hint}</span>
        ) : null}
      </div>
    </div>
  );
}
